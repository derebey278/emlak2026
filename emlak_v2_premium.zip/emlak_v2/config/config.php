<?php
declare(strict_types=1);

date_default_timezone_set('Europe/Istanbul');

define('DB_HOST', 'localhost');
define('DB_NAME', 'nusayzbj_DNM');
define('DB_USER', 'nusayzbj_DNM');
define('DB_PASS', 'nusayzbj_DNM');

define('APP_NAME', 'Nusaybin Prestij Emlak');
define('APP_URL', 'http://localhost/tek-isletme-emlak/public');
define('ADMIN_USER', 'admin');
define('ADMIN_PASS', '123456');

$office = [
    'name' => 'Nusaybin Prestij Emlak',
    'owner' => 'Yetkili Danisman',
    'phone' => '+90 532 000 47 00',
    'whatsapp' => '905320004700',
    'email' => 'info@nusaybinprestijemlak.com',
    'address' => '8 Mart Mahallesi, Nusaybin / Mardin',
    'tax_office' => 'Nusaybin Vergi Dairesi',
    'license_no' => '4700001',
];

$nusaybinNeighborhoods = [
    '8 Mart', 'Abdulkadirpasa', 'Acikkoy', 'Acikyol', 'Akagil', 'Akarsu',
    'Akcatarla', 'Bahcebasi', 'Bakacik', 'Balaban', 'Baris', 'Beylik',
    'Buyukkardes', 'Caglar', 'Cali', 'Catalozu', 'Cigdem', 'Cilesiz',
    'Colova', 'DagicI', 'Dalliagac', 'Demirtepe', 'Devrim', 'Dibek',
    'Dicle', 'Dirim', 'Doganli', 'Dogus', 'Durakbasi', 'Duruca', 'Duzce',
    'Eskihisar', 'Eskimagara', 'Eskiyol', 'Firat', 'Girmeli', 'Girnavas',
    'Gorentepe', 'Gunebakan', 'Guneli', 'Gunyurdu', 'Gurun', 'Guvenli',
    'Hasantepe', 'Heybeli', 'Ilkadim', 'Ipekyolu', 'Ikiztepe', 'Kalecik',
    'Kaleli', 'Kantar', 'Karaca', 'Kayadibi', 'Kisla', 'Kocadag',
    'Kurukoy', 'Kucukkardes', 'Kuyular', 'Mor-Yakup', 'Nergizli',
    'Odabasi', 'Pazar', 'Selahaddin Eyyubi', 'Sinirtepe', 'Sogutlu',
    'Taskoy', 'Tepealti', 'Tepeoren', 'Tepeustu', 'Turgutkoy', 'Uckoy',
    'Ucyol', 'Yandere', 'Yavrukoy', 'Yazyurdu', 'Yenisehir', 'Yenituran',
    'Yerkoy', 'Yesilkent', 'Yolbilen', 'Yolindi', 'Zeynelabidin',
];
