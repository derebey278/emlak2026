CREATE DATABASE IF NOT EXISTS tek_isletme_emlak CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE tek_isletme_emlak;

DROP TABLE IF EXISTS demand_listing_matches;
DROP TABLE IF EXISTS rental_contracts;
DROP TABLE IF EXISTS demands;
DROP TABLE IF EXISTS listings;
DROP TABLE IF EXISTS office_settings;

CREATE TABLE office_settings (
    setting_key VARCHAR(80) PRIMARY KEY,
    setting_value TEXT NULL
) ENGINE=InnoDB;

CREATE TABLE listings (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(180) NOT NULL,
    status ENUM('Kiralik', 'Satilik') NOT NULL,
    city VARCHAR(80) NOT NULL DEFAULT 'Mardin',
    district VARCHAR(80) NOT NULL DEFAULT 'Nusaybin',
    neighborhood VARCHAR(100) NOT NULL,
    room_count VARCHAR(20) NOT NULL,
    price INT UNSIGNED NOT NULL,
    gross_m2 INT UNSIGNED NOT NULL,
    description TEXT NOT NULL,
    images JSON NULL,
    is_featured TINYINT(1) NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    view_count INT UNSIGNED NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NULL,
    INDEX idx_filter (city, district, neighborhood, status, room_count, price),
    INDEX idx_featured (is_featured, created_at)
) ENGINE=InnoDB;

INSERT INTO office_settings (setting_key, setting_value) VALUES
('name', 'Nusaybin Prestij Emlak'),
('owner', 'Yetkili Danisman'),
('phone', '+90 532 000 47 00'),
('whatsapp', '905320004700'),
('email', 'info@nusaybinprestijemlak.com'),
('address', '8 Mart Mahallesi, Nusaybin / Mardin'),
('tax_office', 'Nusaybin Vergi Dairesi'),
('license_no', '4700001'),
('logo_path', '');

CREATE TABLE demands (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(140) NOT NULL,
    phone VARCHAR(40) NOT NULL,
    status ENUM('Kiralik', 'Satilik') NOT NULL,
    neighborhood VARCHAR(100) NULL,
    room_count VARCHAR(20) NULL,
    max_price INT UNSIGNED NULL,
    note TEXT NULL,
    source_listing_id INT UNSIGNED NULL,
    created_at DATETIME NOT NULL,
    INDEX idx_demand_match (status, neighborhood, room_count, max_price),
    CONSTRAINT fk_demands_listing FOREIGN KEY (source_listing_id) REFERENCES listings(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE demand_listing_matches (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    demand_id INT UNSIGNED NOT NULL,
    listing_id INT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL,
    UNIQUE KEY uniq_match (demand_id, listing_id),
    CONSTRAINT fk_match_demand FOREIGN KEY (demand_id) REFERENCES demands(id) ON DELETE CASCADE,
    CONSTRAINT fk_match_listing FOREIGN KEY (listing_id) REFERENCES listings(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE rental_contracts (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    listing_id INT UNSIGNED NULL,
    city VARCHAR(80) NOT NULL DEFAULT 'Mardin',
    district VARCHAR(80) NOT NULL DEFAULT 'Nusaybin',
    neighborhood VARCHAR(100) NOT NULL,
    street VARCHAR(180) NULL,
    door_no VARCHAR(80) NULL,
    electric_subscriber_no VARCHAR(80) NULL,
    water_subscriber_no VARCHAR(80) NULL,
    gas_subscriber_no VARCHAR(80) NULL,
    tenant_name VARCHAR(140) NOT NULL,
    tenant_tc VARCHAR(20) NOT NULL,
    tenant_phone VARCHAR(40) NOT NULL,
    tenant_address TEXT NULL,
    landlord_name VARCHAR(140) NOT NULL,
    landlord_tc VARCHAR(20) NOT NULL,
    landlord_phone VARCHAR(40) NOT NULL,
    landlord_address TEXT NULL,
    property_address TEXT NOT NULL,
    monthly_rent INT UNSIGNED NOT NULL,
    deposit INT UNSIGNED NOT NULL,
    rental_period VARCHAR(80) NOT NULL DEFAULT '1 YIL',
    annual_rent INT UNSIGNED NOT NULL DEFAULT 0,
    usage_type VARCHAR(80) NOT NULL DEFAULT 'MESKEN',
    property_condition VARCHAR(120) NOT NULL DEFAULT 'BOS',
    fixtures TEXT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    payment_day TINYINT UNSIGNED NOT NULL,
    special_terms TEXT NULL,
    created_at DATETIME NOT NULL,
    INDEX idx_end_date (end_date),
    CONSTRAINT fk_contract_listing FOREIGN KEY (listing_id) REFERENCES listings(id) ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT INTO listings (title, status, city, district, neighborhood, room_count, price, gross_m2, description, images, is_featured, is_active, view_count, created_at) VALUES
('8 Mart Mahallesinde genis aile dairesi', 'Satilik', 'Mardin', 'Nusaybin', '8 Mart', '3+1', 2450000, 165, 'Merkezi konumda, krediye uygun, bakimli ve ferah 3+1 daire. Okul, market ve toplu ulasima yurume mesafesindedir.', '["https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1400&q=80","https://images.unsplash.com/photo-1560184897-ae75f418493e?auto=format&fit=crop&w=1400&q=80"]', 1, 1, 38, NOW()),
('Baris Mahallesinde esyali kiralik 2+1', 'Kiralik', 'Mardin', 'Nusaybin', 'Baris', '2+1', 14500, 110, 'Temiz kullanilmis, esyali, aileye uygun kiralik daire. Depozito ve sozlesme sureci ofis tarafindan takip edilir.', '["https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=1400&q=80","https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1400&q=80"]', 1, 1, 64, NOW()),
('Yenisehirde site ici satilik 4+1', 'Satilik', 'Mardin', 'Nusaybin', 'Yenisehir', '4+1', 3850000, 210, 'Site icinde otoparkli, genis balkonlu, ebeveyn banyolu prestijli daire.', '["https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1400&q=80"]', 1, 1, 22, NOW()),
('Firat Mahallesinde uygun fiyatli kiralik 3+1', 'Kiralik', 'Mardin', 'Nusaybin', 'Firat', '3+1', 12000, 135, 'Caddeye yakin, temiz, aile apartmani. Uzun sureli kiraci tercih edilir.', '["https://images.unsplash.com/photo-1560185127-6ed189bf02f4?auto=format&fit=crop&w=1400&q=80"]', 0, 1, 17, NOW()),
('Ipekyolu uzerinde dukkan', 'Kiralik', 'Mardin', 'Nusaybin', 'Ipekyolu', 'Dukkan', 30000, 95, 'Yogun yaya trafigi olan lokasyonda, tabela degeri yuksek kiralik dukkan.', '["https://images.unsplash.com/photo-1494526585095-c41746248156?auto=format&fit=crop&w=1400&q=80"]', 0, 1, 11, NOW());

INSERT INTO demands (full_name, phone, status, neighborhood, room_count, max_price, note, source_listing_id, created_at) VALUES
('Mehmet Demir', '0532 111 22 33', 'Kiralik', 'Baris', '2+1', 16000, 'Esyali veya temiz bos daire ariyor.', NULL, NOW()),
('Zeynep Kaya', '0544 222 33 44', 'Satilik', '8 Mart', '3+1', 2600000, 'Krediye uygun daire talebi.', NULL, NOW());

INSERT INTO rental_contracts (listing_id, city, district, neighborhood, street, door_no, electric_subscriber_no, water_subscriber_no, gas_subscriber_no, tenant_name, tenant_tc, tenant_phone, tenant_address, landlord_name, landlord_tc, landlord_phone, landlord_address, property_address, monthly_rent, deposit, rental_period, annual_rent, usage_type, property_condition, fixtures, start_date, end_date, payment_day, special_terms, created_at) VALUES
(2, 'Mardin', 'Nusaybin', 'Baris', 'Merkez Cadde', 'B Blok Daire 4', '07528727', '1116213', '33164617-2025', 'Ahmet Yilmaz', '11111111110', '0533 444 55 66', 'Baris Mahallesi, Nusaybin / Mardin', 'Hasan Celik', '22222222220', '0532 777 88 99', '-', 'Baris Mahallesi, Merkez Cadde, B Blok Daire 4, Nusaybin / Mardin', 14500, 14500, '1 YIL', 174000, 'MESKEN', 'BOS', 'Dairedeki musluklar, pimapen camlar, kapilar ve teslim edilen anahtarlar saglam ve temiz sekilde teslim edilmistir.', DATE_SUB(CURDATE(), INTERVAL 25 DAY), DATE_ADD(CURDATE(), INTERVAL 20 DAY), 5, 'Apartman aidati kiraciya aittir.', DATE_SUB(NOW(), INTERVAL 5 DAY)),
(4, 'Mardin', 'Nusaybin', 'Firat', 'Firat Sokak', 'No:12 Daire:3', '', '', '', 'Elif Sahin', '33333333330', '0543 101 20 30', 'Firat Mahallesi, Nusaybin / Mardin', 'Murat Arslan', '44444444440', '0530 333 44 55', '-', 'Firat Mahallesi, Firat Sokak, No:12 Daire:3, Nusaybin / Mardin', 12000, 12000, '1 YIL', 144000, 'MESKEN', 'BOS', 'Kiralanan bos, temiz ve kullanima elverisli sekilde teslim edilmistir.', DATE_SUB(CURDATE(), INTERVAL 90 DAY), DATE_ADD(CURDATE(), INTERVAL 120 DAY), 10, '', DATE_SUB(NOW(), INTERVAL 20 DAY));
