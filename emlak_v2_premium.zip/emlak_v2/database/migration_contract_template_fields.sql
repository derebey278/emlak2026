USE tek_isletme_emlak;

CREATE TABLE IF NOT EXISTS office_settings (
    setting_key VARCHAR(80) PRIMARY KEY,
    setting_value TEXT NULL
) ENGINE=InnoDB;

INSERT INTO office_settings (setting_key, setting_value) VALUES
('name', 'Nusaybin Prestij Emlak'),
('owner', 'Yetkili Danisman'),
('phone', '+90 532 000 47 00'),
('whatsapp', '905320004700'),
('email', 'info@nusaybinprestijemlak.com'),
('address', '8 Mart Mahallesi, Nusaybin / Mardin'),
('tax_office', 'Nusaybin Vergi Dairesi'),
('license_no', '4700001'),
('logo_path', '')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

ALTER TABLE listings ADD COLUMN IF NOT EXISTS updated_at DATETIME NULL;

ALTER TABLE rental_contracts
    ADD COLUMN IF NOT EXISTS city VARCHAR(80) NOT NULL DEFAULT 'Mardin' AFTER listing_id,
    ADD COLUMN IF NOT EXISTS district VARCHAR(80) NOT NULL DEFAULT 'Nusaybin' AFTER city,
    ADD COLUMN IF NOT EXISTS neighborhood VARCHAR(100) NOT NULL DEFAULT '' AFTER district,
    ADD COLUMN IF NOT EXISTS street VARCHAR(180) NULL AFTER neighborhood,
    ADD COLUMN IF NOT EXISTS door_no VARCHAR(80) NULL AFTER street,
    ADD COLUMN IF NOT EXISTS electric_subscriber_no VARCHAR(80) NULL AFTER door_no,
    ADD COLUMN IF NOT EXISTS water_subscriber_no VARCHAR(80) NULL AFTER electric_subscriber_no,
    ADD COLUMN IF NOT EXISTS gas_subscriber_no VARCHAR(80) NULL AFTER water_subscriber_no,
    ADD COLUMN IF NOT EXISTS tenant_address TEXT NULL AFTER tenant_phone,
    ADD COLUMN IF NOT EXISTS landlord_address TEXT NULL AFTER landlord_phone,
    ADD COLUMN IF NOT EXISTS rental_period VARCHAR(80) NOT NULL DEFAULT '1 YIL' AFTER deposit,
    ADD COLUMN IF NOT EXISTS annual_rent INT UNSIGNED NOT NULL DEFAULT 0 AFTER rental_period,
    ADD COLUMN IF NOT EXISTS usage_type VARCHAR(80) NOT NULL DEFAULT 'MESKEN' AFTER annual_rent,
    ADD COLUMN IF NOT EXISTS property_condition VARCHAR(120) NOT NULL DEFAULT 'BOS' AFTER usage_type,
    ADD COLUMN IF NOT EXISTS fixtures TEXT NULL AFTER property_condition;
