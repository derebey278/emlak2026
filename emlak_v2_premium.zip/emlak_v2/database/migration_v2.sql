-- Migration v2: Personel tablosu + İlan yeni alanları
-- Bu dosyayı mevcut veritabanında bir kez çalıştırın.

-- Personel tablosu
CREATE TABLE IF NOT EXISTS staff (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(140) NOT NULL,
    phone VARCHAR(40) NULL,
    email VARCHAR(140) NULL,
    role VARCHAR(80) NULL COMMENT 'Emlakçı, Koordinatör vb.',
    note TEXT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NULL
) ENGINE=InnoDB;

-- İlanlara ek alanlar (m², kat, bina yaşı, ısıtma)
ALTER TABLE listings
    ADD COLUMN IF NOT EXISTS net_m2 INT UNSIGNED NOT NULL DEFAULT 0 AFTER gross_m2,
    ADD COLUMN IF NOT EXISTS floor VARCHAR(40) NULL AFTER net_m2,
    ADD COLUMN IF NOT EXISTS building_age VARCHAR(40) NULL AFTER floor,
    ADD COLUMN IF NOT EXISTS heating VARCHAR(80) NULL AFTER building_age;
