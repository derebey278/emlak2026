<?php $imgs = listing_images($listing); $img = $imgs[0]; ?>
<article class="card">
    <a class="card-media" href="listing.php?id=<?= (int)$listing['id'] ?>">
        <img src="<?= e($img) ?>" alt="<?= e($listing['title']) ?>" loading="lazy">
        <span class="media-tag"><?= e($listing['status'] === 'Kiralik' ? 'KİRALIK' : 'SATILIK') ?></span>
        <?php if ($listing['is_featured']): ?><span class="media-featured">⭐ Vitrin</span><?php endif; ?>
    </a>
    <div class="card-body">
        <h3><?= e($listing['title']) ?></h3>
        <div class="meta">
            <span>📍 <?= e($listing['neighborhood']) ?></span>
            <span>🛏 <?= e($listing['room_count']) ?></span>
            <span>📐 <?= (int)$listing['gross_m2'] ?> m²</span>
            <?php if (!empty($listing['floor'])): ?><span>🏢 Kat <?= e($listing['floor']) ?></span><?php endif; ?>
        </div>
        <div class="price"><?= money_fmt($listing['price']) ?><?= $listing['status'] === 'Kiralik' ? '<small style="font-size:14px;font-weight:400">/ay</small>' : '' ?></div>
        <a class="btn" href="listing.php?id=<?= (int)$listing['id'] ?>">İncele</a>
    </div>
</article>
