<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';

function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function money_fmt($amount): string
{
    return number_format((float) $amount, 0, ',', '.') . ' TL';
}

function selected(string $a, string $b): string
{
    return $a === $b ? ' selected' : '';
}

function checked(bool $state): string
{
    return $state ? ' checked' : '';
}

function post(string $key, $default = '')
{
    return $_POST[$key] ?? $default;
}

function flash(string $type, string $message): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function flashes(): array
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    $items = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $items;
}

function redirect(string $path): void
{
    header('Location: ' . $path);
    exit;
}

function csrf_token(): string
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf(): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    $sent = (string) ($_POST['csrf_token'] ?? '');
    $known = (string) ($_SESSION['csrf_token'] ?? '');
    if ($sent === '' || $known === '' || !hash_equals($known, $sent)) {
        http_response_code(419);
        exit('Gecersiz form oturumu. Lutfen sayfayi yenileyip tekrar deneyin.');
    }
}

function is_valid_date(string $date): bool
{
    $parsed = DateTime::createFromFormat('Y-m-d', $date);
    return $parsed instanceof DateTime && $parsed->format('Y-m-d') === $date;
}

function require_fields(array $fields): void
{
    foreach ($fields as $field) {
        if (trim((string) post($field)) === '') {
            flash('error', 'Lutfen zorunlu alanlari eksiksiz doldurun.');
            redirect($_SERVER['HTTP_REFERER'] ?? $_SERVER['REQUEST_URI'] ?? 'index.php');
        }
    }
}

function get_listings(array $filters = [], bool $featuredOnly = false): array
{
    $where = ['is_active = 1'];
    $params = [];

    if ($featuredOnly) {
        $where[] = 'is_featured = 1';
    }
    foreach (['city', 'district', 'neighborhood', 'status', 'room_count'] as $field) {
        if (!empty($filters[$field])) {
            $where[] = "$field = :$field";
            $params[$field] = $filters[$field];
        }
    }
    if (!empty($filters['min_price'])) {
        $where[] = 'price >= :min_price';
        $params['min_price'] = (int) $filters['min_price'];
    }
    if (!empty($filters['min_m2'])) { $where[] = 'gross_m2 >= :min_m2'; $params['min_m2'] = (int)$filters['min_m2']; }
    if (!empty($filters['max_m2'])) { $where[] = 'gross_m2 <= :max_m2'; $params['max_m2'] = (int)$filters['max_m2']; }
    if (!empty($filters['max_price'])) {
        $where[] = 'price <= :max_price';
        $params['max_price'] = (int) $filters['max_price'];
    }

    $sql = 'SELECT * FROM listings WHERE ' . implode(' AND ', $where) . ' ORDER BY is_featured DESC, created_at DESC';
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function find_listing(int $id): ?array
{
    $stmt = db()->prepare('SELECT * FROM listings WHERE id = :id AND is_active = 1');
    $stmt->execute(['id' => $id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function find_listing_admin(int $id): ?array
{
    $stmt = db()->prepare('SELECT * FROM listings WHERE id = :id');
    $stmt->execute(['id' => $id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function listing_images(array $listing): array
{
    $images = json_decode((string) $listing['images'], true);
    if (!is_array($images) || $images === []) {
        return ['https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=1400&q=80'];
    }
    return $images;
}

function upload_listing_images(string $field = 'photos'): array
{
    if (empty($_FILES[$field]) || !is_array($_FILES[$field]['name'])) {
        return [];
    }

    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    $uploadDir = __DIR__ . '/../public/assets/uploads';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0775, true);
    }

    $saved = [];
    foreach ($_FILES[$field]['name'] as $index => $name) {
        if ($_FILES[$field]['error'][$index] === UPLOAD_ERR_NO_FILE) {
            continue;
        }
        if ($_FILES[$field]['error'][$index] !== UPLOAD_ERR_OK) {
            flash('error', 'Bir resim yuklenemedi: ' . e((string) $name));
            continue;
        }
        if ($_FILES[$field]['size'][$index] > 5 * 1024 * 1024) {
            flash('error', 'Resim 5 MB sinirini asiyor: ' . e((string) $name));
            continue;
        }

        $tmp = $_FILES[$field]['tmp_name'][$index];
        $mime = mime_content_type($tmp);
        if (!isset($allowed[$mime])) {
            flash('error', 'Sadece JPG, PNG veya WEBP resim yukleyin: ' . e((string) $name));
            continue;
        }

        $filename = 'ilan-' . date('YmdHis') . '-' . bin2hex(random_bytes(5)) . '.' . $allowed[$mime];
        $target = $uploadDir . '/' . $filename;
        if (move_uploaded_file($tmp, $target)) {
            $saved[] = 'assets/uploads/' . $filename;
        }
    }

    return $saved;
}

function office_settings(): array
{
    global $office;
    $defaults = [
        'name' => $office['name'] ?? APP_NAME,
        'owner' => $office['owner'] ?? '',
        'phone' => $office['phone'] ?? '',
        'whatsapp' => $office['whatsapp'] ?? '',
        'email' => $office['email'] ?? '',
        'address' => $office['address'] ?? '',
        'tax_office' => $office['tax_office'] ?? '',
        'license_no' => $office['license_no'] ?? '',
        'logo_path' => '',
    ];

    try {
        $stmt = db()->query('SELECT setting_key, setting_value FROM office_settings');
        foreach ($stmt->fetchAll() as $row) {
            $defaults[$row['setting_key']] = $row['setting_value'];
        }
    } catch (Throwable $e) {
        // Fresh installs before schema import still use config.php values.
    }

    return $defaults;
}

function save_office_settings(array $settings): void
{
    $stmt = db()->prepare('INSERT INTO office_settings (setting_key, setting_value) VALUES (:setting_key, :setting_value) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)');
    foreach ($settings as $key => $value) {
        $stmt->execute(['setting_key' => $key, 'setting_value' => (string) $value]);
    }
}

function upload_logo(): ?string
{
    if (empty($_FILES['logo']) || $_FILES['logo']['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    if ($_FILES['logo']['error'] !== UPLOAD_ERR_OK || $_FILES['logo']['size'] > 2 * 1024 * 1024) {
        flash('error', 'Logo yuklenemedi. En fazla 2 MB JPG, PNG veya WEBP kullanin.');
        return null;
    }
    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    $mime = mime_content_type($_FILES['logo']['tmp_name']);
    if (!isset($allowed[$mime])) {
        flash('error', 'Logo JPG, PNG veya WEBP olmalidir.');
        return null;
    }
    $uploadDir = __DIR__ . '/../public/assets/uploads';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0775, true);
    }
    $filename = 'logo-' . date('YmdHis') . '.' . $allowed[$mime];
    if (move_uploaded_file($_FILES['logo']['tmp_name'], $uploadDir . '/' . $filename)) {
        return 'assets/uploads/' . $filename;
    }
    flash('error', 'Logo dosyasi kaydedilemedi.');
    return null;
}

function suitable_listings_for_demand(array $demand): array
{
    $where = ['is_active = 1'];
    $params = [];

    foreach (['status', 'neighborhood', 'room_count'] as $field) {
        if (!empty($demand[$field])) {
            $where[] = "$field = :$field";
            $params[$field] = $demand[$field];
        }
    }
    if (!empty($demand['max_price'])) {
        $where[] = 'price <= :max_price';
        $params['max_price'] = (int) $demand['max_price'];
    }

    $stmt = db()->prepare('SELECT * FROM listings WHERE ' . implode(' AND ', $where) . ' ORDER BY is_featured DESC, price ASC');
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function contract_status(array $contract): array
{
    $today = new DateTimeImmutable('today');
    $created = new DateTimeImmutable($contract['created_at']);
    $end = new DateTimeImmutable($contract['end_date']);
    $daysLeft = (int) $today->diff($end)->format('%r%a');

    if ($created >= $today->modify('-7 days')) {
        return ['label' => 'Son 7 gun', 'class' => 'blue', 'days_left' => $daysLeft];
    }
    if ($daysLeft <= 30) {
        return ['label' => 'Bitmeye yakin', 'class' => 'red', 'days_left' => $daysLeft];
    }
    return ['label' => 'Takipte', 'class' => 'yellow', 'days_left' => $daysLeft];
}

function require_admin(): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    if (empty($_SESSION['admin'])) {
        header('Location: login.php');
        exit;
    }
}

function match_count_for_demand(array $demand): int
{
    return count(suitable_listings_for_demand($demand));
}

function staff_count(): int {
    try {
        return (int) db()->query('SELECT COUNT(*) FROM staff')->fetchColumn();
    } catch (Throwable $e) {
        return 0;
    }
}
