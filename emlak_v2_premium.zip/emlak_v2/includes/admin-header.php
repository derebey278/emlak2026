<?php require_admin(); ?>
<?php $adminOffice = office_settings(); ?>
<!doctype html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Yönetici Paneli | <?= e(APP_NAME) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="../public/assets/styles.css">
</head>
<body class="admin-body">
<div class="admin-layout">
    <aside class="sidebar">
        <div class="sidebar-brand">
            <div class="sidebar-gem"></div>
            <div>
                <div class="sidebar-brand-name"><?= e($adminOffice['name'] ?? APP_NAME) ?></div>
                <div class="sidebar-brand-sub">Yönetici Paneli</div>
            </div>
        </div>
        <div class="sidebar-section">Genel</div>
        <a href="index.php">🏠 Panel Özeti</a>
        <a href="listings.php">🏢 İlanlar</a>
        <a href="demands.php">📋 Talepler</a>
        <div class="sidebar-section">Yönetim</div>
        <a href="contracts.php">📄 Kira Sözleşmeleri</a>
        <a href="staff.php">👤 Personel / Emlakçı</a>
        <a href="reports.php">📊 Raporlama</a>
        <div class="sidebar-section">Sistem</div>
        <a href="settings.php">⚙️ Ofis Ayarları</a>
        <a href="../public/index.php" target="_blank">🌐 Siteye Git</a>
        <div class="sidebar-footer">
            <a href="logout.php">🚪 Çıkış</a>
        </div>
    </aside>
    <main class="admin-main">
        <?php foreach (flashes() as $flash): ?>
            <div class="notice <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
        <?php endforeach; ?>
