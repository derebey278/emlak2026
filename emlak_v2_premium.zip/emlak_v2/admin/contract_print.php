<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

$office = office_settings();

$stmt = db()->prepare('SELECT * FROM rental_contracts WHERE id = :id');
$stmt->execute(['id' => (int) ($_GET['id'] ?? 0)]);
$contract = $stmt->fetch();
if (!$contract) {
    exit('Sozlesme bulunamadi.');
}
?>
<!doctype html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <title>Kira Sozlesmesi</title>
    <link rel="stylesheet" href="../public/assets/styles.css">
    <style>
        body { background:#fff; }
        .contract { max-width: 980px; margin: 24px auto; line-height: 1.45; font-size: 14px; }
        .contract h1 { text-align:center; margin: 12px 0 18px; letter-spacing: .5px; }
        .contract h2 { background:#f1f5f9; border:1px solid #111; margin: 16px 0 0; padding: 7px 9px; font-size: 16px; }
        .contract-table { width:100%; border-collapse:collapse; }
        .contract-table th, .contract-table td { border:1px solid #111; padding:8px; vertical-align:top; }
        .contract-table th { width: 22%; background:#f8fafc; text-align:left; }
        .split { display:grid; grid-template-columns:1fr 1fr; gap:0; }
        .split .contract-table:first-child th, .split .contract-table:first-child td { border-right:0; }
        .signature { display:grid; grid-template-columns:repeat(3,1fr); gap:18px; margin-top:50px; text-align:center; }
        .signature div { border-top:1px solid #000; padding-top:10px; min-height:70px; }
        ol { margin-top: 10px; }
        li { margin-bottom: 6px; }
        @media print { .contract { margin: 0; max-width: none; } }
    </style>
</head>
<body>
<main class="contract">
    <button class="btn no-print" onclick="window.print()">PDF olarak kaydet / yazdir</button>
    <h1>KİRA SÖZLEŞMESİ</h1>

    <table class="contract-table">
        <tr>
            <th>İL - İLÇE</th>
            <td><?= e($contract['city']) ?> / <?= e($contract['district']) ?></td>
            <th>MAHALLE</th>
            <td><?= e($contract['neighborhood']) ?></td>
        </tr>
        <tr>
            <th>CADDE - SOKAK</th>
            <td><?= e($contract['street'] ?: '-') ?></td>
            <th>DIŞ KAPI - DAİRE NO</th>
            <td><?= e($contract['door_no'] ?: '-') ?></td>
        </tr>
        <tr>
            <th>ELEKTRİK ABONESİ</th>
            <td><?= e($contract['electric_subscriber_no'] ?: '-') ?></td>
            <th>SU ABONESİ</th>
            <td><?= e($contract['water_subscriber_no'] ?: '-') ?></td>
        </tr>
        <tr>
            <th>DOĞALGAZ ABONESİ</th>
            <td><?= e($contract['gas_subscriber_no'] ?: '-') ?></td>
            <th>EMLAK OFİSİ</th>
            <td><?= e($office['name']) ?> - <?= e($office['phone']) ?></td>
        </tr>
    </table>

    <h2>KİRAYA VEREN VE KİRACI</h2>
    <div class="split">
        <table class="contract-table">
            <tr><th colspan="2">KİRAYA VEREN</th></tr>
            <tr><th>AD SOYAD</th><td><?= e($contract['landlord_name']) ?></td></tr>
            <tr><th>T.C. KİMLİK NO</th><td><?= e($contract['landlord_tc']) ?></td></tr>
            <tr><th>TELEFON NO</th><td><?= e($contract['landlord_phone']) ?></td></tr>
            <tr><th>ADRES</th><td><?= nl2br(e($contract['landlord_address'] ?: '-')) ?></td></tr>
        </table>
        <table class="contract-table">
            <tr><th colspan="2">KİRACI</th></tr>
            <tr><th>AD SOYAD</th><td><?= e($contract['tenant_name']) ?></td></tr>
            <tr><th>T.C. KİMLİK NO</th><td><?= e($contract['tenant_tc']) ?></td></tr>
            <tr><th>TELEFON NO</th><td><?= e($contract['tenant_phone']) ?></td></tr>
            <tr><th>ADRES</th><td><?= nl2br(e($contract['tenant_address'] ?: '-')) ?></td></tr>
        </table>
    </div>

    <h2>KİRALANAN VE KİRA BİLGİLERİ</h2>
    <table class="contract-table">
        <tr><th>KİRALANAN ADRESİ</th><td colspan="3"><?= nl2br(e($contract['property_address'])) ?></td></tr>
        <tr>
            <th>KİRA BAŞLANGIÇ TARİHİ</th><td><?= e(date('d.m.Y', strtotime($contract['start_date']))) ?></td>
            <th>KİRA SÜRESİ</th><td><?= e($contract['rental_period']) ?></td>
        </tr>
        <tr>
            <th>AYLIK KİRA BEDELİ</th><td><?= money_fmt($contract['monthly_rent']) ?></td>
            <th>YILLIK KİRA BEDELİ</th><td><?= money_fmt($contract['annual_rent']) ?></td>
        </tr>
        <tr>
            <th>KİRALANANIN KULLANIM ŞEKLİ</th><td><?= e($contract['usage_type']) ?></td>
            <th>KİRALANAN DURUMU</th><td><?= e($contract['property_condition']) ?></td>
        </tr>
        <tr>
            <th>DEPOZİTO</th><td><?= money_fmt($contract['deposit']) ?></td>
            <th>ÖDEME GÜNÜ</th><td>Her ayın <?= (int) $contract['payment_day'] ?>. günü</td>
        </tr>
        <tr><th>KİRA BİTİŞ TARİHİ</th><td colspan="3"><?= e(date('d.m.Y', strtotime($contract['end_date']))) ?></td></tr>
    </table>

    <h2>KİRALANANLA BİRLİKTE TESLİM EDİLEN DEMİRBAŞLAR</h2>
    <table class="contract-table">
        <tr><td><?= nl2br(e($contract['fixtures'] ?: 'Kiralanan boş, temiz ve kullanıma elverişli şekilde teslim edilmiştir.')) ?></td></tr>
    </table>

    <h2>ÖZEL KOŞULLAR</h2>
    <ol>
        <li>Kira artış oranı, yürürlükteki mevzuat ve yasal sınırlar dikkate alınarak uygulanır.</li>
        <li>Sözleşme süresi <?= e($contract['rental_period']) ?> olup, feshedilmediği sürece 6098 sayılı Türk Borçlar Kanunu hükümlerine göre değerlendirilir.</li>
        <li>Kiracı, sözleşme süresi dolmadan çıkarsa, taşınmaz yeniden kiraya verilene kadar doğan kira kaybından kanuni sınırlar içinde sorumlu olacağını kabul eder.</li>
        <li><?= money_fmt($contract['deposit']) ?> depozito alınmıştır. Kiralananın sağlam ve temiz şekilde teslim edilmesi, borç ve zarar bulunmaması halinde iade edilir.</li>
    </ol>
    <?php if (!empty($contract['special_terms'])): ?>
        <p><?= nl2br(e($contract['special_terms'])) ?></p>
    <?php endif; ?>

    <h2>GENEL KOŞULLAR</h2>
    <ol>
        <li>Kiracı, kiralananı özenle kullanmak zorundadır.</li>
        <li>Kiracı, kiralananda ve çevrede oturanlara iyi niyet kuralları içinde davranmak zorundadır.</li>
        <li>Kiracı, kiraya verenin yazılı izni olmadıkça kiralananda değişiklik yapamaz; aksi halde doğacak zararı karşılamak zorundadır.</li>
        <li>Kiracı, kiraya verenin yazılı izni olmadan taşınmazı başkasına devredemez veya alt kiraya veremez.</li>
        <li>Üçüncü kişilerin kiralanan üzerinde hak iddia etmeleri halinde kiracı, durumu derhal kiraya verene haber vermek zorundadır.</li>
        <li>Kiracı, kiralananda yapılması gereken onarımları derhal kiraya verene bildirmek zorundadır; aksi halde doğacak zarardan sorumludur.</li>
        <li>Kiracı, kat malikleri kurulunca kendisine tebliğ edilen hususları kiraya verene haber vermek zorundadır.</li>
        <li>Kiracı, kat malikleri kurulu kararı uyarınca yapılması gereken işlere izin vermek zorundadır.</li>
        <li>Kiracı, kiralanandaki olağan kullanımdan doğan küçük bakım ve onarım giderlerini karşılamak zorundadır.</li>
        <li>Kiralananın mülkiyet hakkından doğan vergiler kiraya verene; kullanımdan doğan vergi, resim, harç, elektrik, su, doğalgaz, internet ve aidat giderleri kiracıya aittir.</li>
        <li>Kiralananın iyi ve kullanılmaya elverişli halde teslim edildiği asıldır. Olağan kullanımdan kaynaklanan yıpranma hariç zararlardan kiracı sorumludur.</li>
        <li>Kiracı, kiralanana yaptığı faydalı ve lüks şeylerin bedelini kiraya verenden isteyemez; sözleşme bitiminde bunları kiralananla birlikte teslim eder.</li>
        <li>Kiracı, kiraya verenin yazılı olurunu almak ve giderleri kendisine ait olmak üzere anten, uydu, internet ve benzeri donanımları yaptırabilir.</li>
        <li>Depozito, kira bedeli yerine mahsup edilemez.</li>
        <li>Kiracı, taşınmazı tahliye ederken anahtarı kiraya verene teslim etmedikçe tahliye gerçekleşmiş sayılmaz.</li>
        <li>Bu sözleşme iki nüsha olarak düzenlenmiş olup taraflara verilmiştir.</li>
        <li>Uyuşmazlıkların giderilmesinde Nusaybin mahkemeleri ve icra daireleri yetkilidir.</li>
        <li>Bu sözleşmede yer almayan hususlar hakkında 6098 sayılı Türk Borçlar Kanunu hükümleri geçerlidir.</li>
    </ol>

    <p>İşbu kira sözleşmesi taraflarca okunarak <?= date('d.m.Y') ?> tarihinde imza altına alınmıştır.</p>
    <div class="signature">
        <div>Kiraya Veren<br><?= e($contract['landlord_name']) ?></div>
        <div>Kiraci<br><?= e($contract['tenant_name']) ?></div>
        <div>Emlak Ofisi<br><?= e($office['name']) ?></div>
    </div>
</main>
</body>
</html>
