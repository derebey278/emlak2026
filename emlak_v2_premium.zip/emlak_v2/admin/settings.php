<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

$settings = office_settings();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    require_fields(['name', 'phone', 'whatsapp', 'email', 'address']);

    $newLogo = upload_logo();
    $data = [
        'name' => trim((string) post('name')),
        'owner' => trim((string) post('owner')),
        'phone' => trim((string) post('phone')),
        'whatsapp' => preg_replace('/\D+/', '', (string) post('whatsapp')),
        'email' => trim((string) post('email')),
        'address' => trim((string) post('address')),
        'tax_office' => trim((string) post('tax_office')),
        'license_no' => trim((string) post('license_no')),
        'logo_path' => $newLogo ?: ($settings['logo_path'] ?? ''),
    ];

    if (!empty($_POST['remove_logo'])) {
        $data['logo_path'] = '';
    }

    save_office_settings($data);
    flash('success', 'Ofis bilgileri guncellendi.');
    redirect('settings.php');
}

include __DIR__ . '/../includes/admin-header.php';
?>
<div class="admin-title">
    <div>
        <h1>Ofis ayarlari</h1>
        <p>Site uzerindeki marka, logo ve iletisim bilgilerini buradan yonetin.</p>
    </div>
</div>

<div class="panel">
    <?php if (!empty($settings['logo_path'])): ?>
        <div class="logo-preview">
            <img src="../public/<?= e($settings['logo_path']) ?>" alt="Ofis logosu">
        </div>
    <?php endif; ?>
    <form method="post" enctype="multipart/form-data" class="form-grid">
        <?= csrf_field() ?>
        <input name="name" value="<?= e($settings['name']) ?>" placeholder="Ofis adi" required>
        <input name="owner" value="<?= e($settings['owner']) ?>" placeholder="Yetkili kisi">
        <input name="phone" value="<?= e($settings['phone']) ?>" placeholder="Telefon" required>
        <input name="whatsapp" value="<?= e($settings['whatsapp']) ?>" placeholder="WhatsApp numarasi" required>
        <input name="email" value="<?= e($settings['email']) ?>" placeholder="E-posta" required>
        <input name="license_no" value="<?= e($settings['license_no']) ?>" placeholder="Yetki belge no">
        <input name="tax_office" value="<?= e($settings['tax_office']) ?>" placeholder="Vergi dairesi">
        <input type="file" name="logo" accept="image/jpeg,image/png,image/webp">
        <textarea class="full" name="address" placeholder="Adres" required><?= e($settings['address']) ?></textarea>
        <label><input style="width:auto" type="checkbox" name="remove_logo" value="1"> Mevcut logoyu kaldir</label>
        <button type="submit">Ofis bilgilerini kaydet</button>
    </form>
</div>
<?php include __DIR__ . '/../includes/admin-footer.php'; ?>
