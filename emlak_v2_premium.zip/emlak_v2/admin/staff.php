<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string) post('action', 'save');
    $id = (int) post('id', 0);

    if ($action === 'delete' && $id > 0) {
        db()->prepare('DELETE FROM staff WHERE id = :id')->execute(['id' => $id]);
        flash('success', 'Personel silindi.');
        redirect('staff.php');
    }

    $name  = trim((string) post('full_name'));
    $phone = trim((string) post('phone'));
    $email = trim((string) post('email'));
    $role  = trim((string) post('role'));
    $note  = trim((string) post('note'));

    if ($name === '') { flash('error', 'Ad Soyad zorunludur.'); redirect('staff.php'); }

    if ($id > 0) {
        db()->prepare('UPDATE staff SET full_name=:n, phone=:p, email=:e, role=:r, note=:no, updated_at=NOW() WHERE id=:id')
            ->execute(['n'=>$name,'p'=>$phone,'e'=>$email,'r'=>$role,'no'=>$note,'id'=>$id]);
        flash('success', 'Personel güncellendi.');
    } else {
        db()->prepare('INSERT INTO staff (full_name, phone, email, role, note, created_at, updated_at) VALUES (:n,:p,:e,:r,:no,NOW(),NOW())')
            ->execute(['n'=>$name,'p'=>$phone,'e'=>$email,'r'=>$role,'no'=>$note]);
        flash('success', 'Personel eklendi.');
    }
    redirect('staff.php');
}

$editStaff = null;
if (!empty($_GET['edit'])) {
    $s = db()->prepare('SELECT * FROM staff WHERE id=:id');
    $s->execute(['id' => (int)$_GET['edit']]);
    $editStaff = $s->fetch() ?: null;
}
$staffList = db()->query('SELECT * FROM staff ORDER BY created_at DESC')->fetchAll();
include __DIR__ . '/../includes/admin-header.php';
?>
<div class="admin-title">
    <div>
        <h1>Personel / Emlakçı Yönetimi</h1>
        <p>Ofis çalışanlarını ve emlakçıları yönetin.</p>
    </div>
    <a class="btn sm secondary" href="staff.php">+ Yeni Personel</a>
</div>

<div class="panel" style="margin-bottom:24px">
    <h2><?= $editStaff ? 'Personeli Düzenle' : 'Yeni Personel Ekle' ?></h2>
    <form method="post" class="form-grid">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= $editStaff ? (int)$editStaff['id'] : 0 ?>">
        <div class="form-group">
            <label>Ad Soyad *</label>
            <input name="full_name" value="<?= e($editStaff['full_name'] ?? '') ?>" placeholder="Ad Soyad" required>
        </div>
        <div class="form-group">
            <label>Görev / Unvan</label>
            <input name="role" value="<?= e($editStaff['role'] ?? '') ?>" placeholder="Emlakçı, Koordinatör…">
        </div>
        <div class="form-group">
            <label>Telefon</label>
            <input name="phone" value="<?= e($editStaff['phone'] ?? '') ?>" placeholder="+90 5xx xxx xx xx">
        </div>
        <div class="form-group">
            <label>E-posta</label>
            <input name="email" value="<?= e($editStaff['email'] ?? '') ?>" placeholder="ad@ofis.com">
        </div>
        <div class="form-group full">
            <label>Not</label>
            <textarea name="note" rows="2"><?= e($editStaff['note'] ?? '') ?></textarea>
        </div>
        <div style="display:flex;gap:10px">
            <button type="submit"><?= $editStaff ? 'Güncelle' : 'Kaydet' ?></button>
            <?php if ($editStaff): ?><a class="btn secondary" href="staff.php">İptal</a><?php endif; ?>
        </div>
    </form>
</div>

<table class="table">
    <tr><th>Ad Soyad</th><th>Görev</th><th>Telefon</th><th>E-posta</th><th>Not</th><th>Eklenme</th><th></th></tr>
    <?php if ($staffList === []): ?>
        <tr><td colspan="7" style="color:var(--muted);text-align:center;padding:24px">Henüz personel eklenmedi.</td></tr>
    <?php endif; ?>
    <?php foreach ($staffList as $s): ?>
        <tr>
            <td><strong><?= e($s['full_name']) ?></strong></td>
            <td><?= e($s['role'] ?: '–') ?></td>
            <td><?= e($s['phone'] ?: '–') ?></td>
            <td><?= e($s['email'] ?: '–') ?></td>
            <td><small><?= e($s['note'] ?: '–') ?></small></td>
            <td><small><?= e(date('d.m.Y', strtotime($s['created_at']))) ?></small></td>
            <td class="actions">
                <a class="btn sm" href="staff.php?edit=<?= (int)$s['id'] ?>">Düzenle</a>
                <form method="post" onsubmit="return confirm('Silmek istediğinize emin misiniz?')">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
                    <button class="btn danger-btn sm" type="submit">Sil</button>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
<?php include __DIR__ . '/../includes/admin-footer.php'; ?>
