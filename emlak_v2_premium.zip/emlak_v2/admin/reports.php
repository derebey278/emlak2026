<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

// Stats
$totalListings   = (int) db()->query('SELECT COUNT(*) FROM listings')->fetchColumn();
$activeListings  = (int) db()->query('SELECT COUNT(*) FROM listings WHERE is_active=1')->fetchColumn();
$kiralik         = (int) db()->query("SELECT COUNT(*) FROM listings WHERE status='Kiralik' AND is_active=1")->fetchColumn();
$satilik         = (int) db()->query("SELECT COUNT(*) FROM listings WHERE status='Satilik' AND is_active=1")->fetchColumn();
$totalDemands    = (int) db()->query('SELECT COUNT(*) FROM demands')->fetchColumn();
$totalContracts  = (int) db()->query('SELECT COUNT(*) FROM rental_contracts')->fetchColumn();
$totalRent       = (int) db()->query('SELECT COALESCE(SUM(monthly_rent),0) FROM rental_contracts')->fetchColumn();
$avgPrice        = (int) db()->query('SELECT COALESCE(AVG(price),0) FROM listings WHERE is_active=1')->fetchColumn();

// Mahalle bazlı ilan dağılımı (top 8)
$neighborhoodData = db()->query('SELECT neighborhood, COUNT(*) as cnt FROM listings WHERE is_active=1 GROUP BY neighborhood ORDER BY cnt DESC LIMIT 8')->fetchAll();

// Aylık ilan (son 12 ay)
$monthly = db()->query("SELECT DATE_FORMAT(created_at,'%b %Y') AS mon, COUNT(*) AS cnt FROM listings WHERE created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH) GROUP BY DATE_FORMAT(created_at,'%Y-%m') ORDER BY DATE_FORMAT(created_at,'%Y-%m')")->fetchAll();

// Oda dağılımı
$roomData = db()->query("SELECT room_count, COUNT(*) as cnt FROM listings WHERE is_active=1 GROUP BY room_count ORDER BY cnt DESC")->fetchAll();

include __DIR__ . '/../includes/admin-header.php';
?>
<div class="admin-title">
    <div>
        <h1>Raporlama & Dashboard</h1>
        <p>Portföy analizi ve istatistikler.</p>
    </div>
</div>

<!-- KPI CARDS -->
<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:24px">
    <div class="stat-card"><div class="stat-icon">🏢</div><div class="stat-card-label">Toplam İlan</div><div class="stat-card-value"><?= $totalListings ?></div><div class="stat-card-sub"><?= $activeListings ?> aktif</div></div>
    <div class="stat-card"><div class="stat-icon">🔑</div><div class="stat-card-label">Kiralık</div><div class="stat-card-value"><?= $kiralik ?></div><div class="stat-card-sub">Aktif kiralık portföy</div></div>
    <div class="stat-card"><div class="stat-icon">🏷️</div><div class="stat-card-label">Satılık</div><div class="stat-card-value"><?= $satilik ?></div><div class="stat-card-sub">Aktif satılık portföy</div></div>
    <div class="stat-card"><div class="stat-icon">💰</div><div class="stat-card-label">Ort. Fiyat</div><div class="stat-card-value" style="font-size:18px"><?= number_format($avgPrice,0,',','.') ?><small style="font-size:12px"> TL</small></div><div class="stat-card-sub">Aktif ilanlar</div></div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:24px">
    <!-- MONTHLY CHART -->
    <div class="panel">
        <h2>Aylık İlan Ekleme (Son 12 Ay)</h2>
        <canvas id="monthChart" height="140"></canvas>
    </div>
    <!-- ROOM DIST -->
    <div class="panel">
        <h2>Oda Sayısı Dağılımı</h2>
        <canvas id="roomChart" height="140"></canvas>
    </div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
    <!-- NEIGHBORHOOD -->
    <div class="panel">
        <h2>Mahalle Bazlı İlan Sayısı (Top 8)</h2>
        <canvas id="neighChart" height="160"></canvas>
    </div>
    <!-- SUMMARY TABLE -->
    <div class="panel">
        <h2>Özet Tablo</h2>
        <table class="table" style="margin-top:0">
            <tr><th>Metrik</th><th>Değer</th></tr>
            <tr><td>Toplam İlan</td><td><strong><?= $totalListings ?></strong></td></tr>
            <tr><td>Aktif İlan</td><td><strong><?= $activeListings ?></strong></td></tr>
            <tr><td>Müşteri Talebi</td><td><strong><?= $totalDemands ?></strong></td></tr>
            <tr><td>Kira Sözleşmesi</td><td><strong><?= $totalContracts ?></strong></td></tr>
            <tr><td>Toplam Kira/Ay</td><td><strong><?= number_format($totalRent,0,',','.') ?> TL</strong></td></tr>
            <tr><td>Ort. İlan Fiyatı</td><td><strong><?= number_format($avgPrice,0,',','.') ?> TL</strong></td></tr>
        </table>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script>
const gold = 'rgba(201,163,90,';
const chartDefaults = { responsive: true, plugins: { legend: { labels: { color: '#7a7a8c' } } }, scales: { x: { ticks:{color:'#7a7a8c'}, grid:{color:'rgba(255,255,255,.04)'} }, y: { ticks:{color:'#7a7a8c'}, grid:{color:'rgba(255,255,255,.04)'} } } };

new Chart(document.getElementById('monthChart'), {
    type: 'line',
    data: {
        labels: <?= json_encode(array_column($monthly, 'mon')) ?>,
        datasets: [{ label: 'İlan', data: <?= json_encode(array_column($monthly, 'cnt')) ?>, borderColor: gold+'1)', backgroundColor: gold+'.12)', tension: .35, fill: true, pointBackgroundColor: gold+'1)' }]
    },
    options: chartDefaults
});

new Chart(document.getElementById('roomChart'), {
    type: 'doughnut',
    data: {
        labels: <?= json_encode(array_column($roomData, 'room_count')) ?>,
        datasets: [{ data: <?= json_encode(array_column($roomData, 'cnt')) ?>, backgroundColor: ['rgba(201,163,90,.8)','rgba(184,115,51,.7)','rgba(228,200,120,.7)','rgba(160,120,48,.7)','rgba(232,228,222,.3)','rgba(122,122,140,.4)','rgba(80,80,100,.4)'] }]
    },
    options: { responsive: true, plugins: { legend: { labels: { color: '#e8e4de' }, position: 'right' } } }
});

new Chart(document.getElementById('neighChart'), {
    type: 'bar',
    data: {
        labels: <?= json_encode(array_column($neighborhoodData, 'neighborhood')) ?>,
        datasets: [{ label: 'İlan Sayısı', data: <?= json_encode(array_column($neighborhoodData, 'cnt')) ?>, backgroundColor: gold+'.55)', borderColor: gold+'1)', borderWidth: 1, borderRadius: 4 }]
    },
    options: { ...chartDefaults, indexAxis: 'y' }
});
</script>
<?php include __DIR__ . '/../includes/admin-footer.php'; ?>
