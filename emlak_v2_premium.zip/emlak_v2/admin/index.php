<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

$stats = [
    'listings'  => (int) db()->query('SELECT COUNT(*) FROM listings WHERE is_active = 1')->fetchColumn(),
    'demands'   => (int) db()->query('SELECT COUNT(*) FROM demands')->fetchColumn(),
    'contracts' => (int) db()->query('SELECT COUNT(*) FROM rental_contracts')->fetchColumn(),
    'staff'     => staff_count(),
];
$totalRevenue = (int) db()->query('SELECT COALESCE(SUM(monthly_rent),0) FROM rental_contracts')->fetchColumn();
$expiringSoon = (int) db()->query("SELECT COUNT(*) FROM rental_contracts WHERE end_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)")->fetchColumn();
$demands = db()->query('SELECT * FROM demands ORDER BY created_at DESC LIMIT 6')->fetchAll();
$contracts = db()->query('SELECT * FROM rental_contracts ORDER BY end_date ASC LIMIT 6')->fetchAll();
// Aylık ilan eklenme verileri (son 6 ay)
$monthlyData = db()->query("SELECT DATE_FORMAT(created_at,'%Y-%m') AS mon, COUNT(*) AS cnt FROM listings WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH) GROUP BY mon ORDER BY mon")->fetchAll();
include __DIR__ . '/../includes/admin-header.php';
?>
<div class="admin-title">
    <div>
        <h1>Panel Özeti</h1>
        <p>Hoş geldiniz — tüm veriler anlık olarak güncellenmektedir.</p>
    </div>
    <a class="btn sm" href="listings.php">+ Yeni İlan</a>
</div>

<!-- STATS -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon">🏢</div>
        <div class="stat-card-label">Aktif İlan</div>
        <div class="stat-card-value"><?= $stats['listings'] ?></div>
        <div class="stat-card-sub">Yayında olan ilanlar</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">📋</div>
        <div class="stat-card-label">Müşteri Talebi</div>
        <div class="stat-card-value"><?= $stats['demands'] ?></div>
        <div class="stat-card-sub">Bekleyen talepler</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">📄</div>
        <div class="stat-card-label">Sözleşme</div>
        <div class="stat-card-value"><?= $stats['contracts'] ?></div>
        <div class="stat-card-sub"><?= $expiringSoon ?> tanesi 30 günde bitiyor</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">💰</div>
        <div class="stat-card-label">Toplam Kira / Ay</div>
        <div class="stat-card-value" style="font-size:22px"><?= number_format($totalRevenue,0,',','.') ?></div>
        <div class="stat-card-sub">TL aktif sözleşmeler</div>
    </div>
</div>

<!-- CHART -->
<div class="panel" style="margin-bottom:24px">
    <h2>Son 6 Ay — İlan Ekleme Grafiği</h2>
    <canvas id="listingsChart" height="80"></canvas>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:24px">
<!-- DEMANDS TABLE -->
<div>
<h2 style="font-family:'Playfair Display',serif;color:var(--gold-light);margin:0 0 12px">Güncel Talepler</h2>
<table class="table">
    <tr><th>Müşteri</th><th>Talep</th><th>Uygun</th><th></th></tr>
    <?php foreach ($demands as $demand): $count = match_count_for_demand($demand); ?>
        <tr>
            <td><strong><?= e($demand['full_name']) ?></strong><br><small><?= e($demand['phone']) ?></small></td>
            <td><?= e($demand['status']) ?> <?= e($demand['room_count']) ?><br><small><?= e($demand['neighborhood'] ?? '–') ?></small></td>
            <td><?= $count > 0 ? '<span class="tag green">'.$count.' ilan</span>' : '<span class="tag">–</span>' ?></td>
            <td><a class="btn sm" href="demands.php?id=<?= (int)$demand['id'] ?>">Eşleştir</a></td>
        </tr>
    <?php endforeach; ?>
</table>
</div>

<!-- CONTRACTS TABLE -->
<div>
<h2 style="font-family:'Playfair Display',serif;color:var(--gold-light);margin:0 0 12px">Yaklaşan Sözleşme Bitişleri</h2>
<table class="table">
    <tr><th>Kiracı</th><th>Adres</th><th>Bitiş</th><th>Durum</th></tr>
    <?php foreach ($contracts as $contract): $status = contract_status($contract); ?>
        <tr>
            <td><strong><?= e($contract['tenant_name']) ?></strong><br><small><?= e($contract['tenant_phone']) ?></small></td>
            <td><?= e($contract['neighborhood']) ?><br><small><?= money_fmt($contract['monthly_rent']) ?>/ay</small></td>
            <td><?= e(date('d.m.Y', strtotime($contract['end_date']))) ?></td>
            <td><span class="tag <?= e($status['class']) ?>"><?= (int)$status['days_left'] ?> gün</span></td>
        </tr>
    <?php endforeach; ?>
</table>
</div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script>
const labels = <?= json_encode(array_column($monthlyData, 'mon')) ?>;
const data   = <?= json_encode(array_column($monthlyData, 'cnt')) ?>;
new Chart(document.getElementById('listingsChart'), {
    type: 'bar',
    data: {
        labels,
        datasets: [{
            label: 'Eklenen İlan',
            data,
            backgroundColor: 'rgba(201,163,90,.55)',
            borderColor: 'rgba(201,163,90,1)',
            borderWidth: 1,
            borderRadius: 4,
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: {
            x: { ticks: { color: '#7a7a8c' }, grid: { color: 'rgba(255,255,255,.04)' } },
            y: { ticks: { color: '#7a7a8c', stepSize: 1 }, grid: { color: 'rgba(255,255,255,.04)' } }
        }
    }
});
</script>
<?php include __DIR__ . '/../includes/admin-footer.php'; ?>
