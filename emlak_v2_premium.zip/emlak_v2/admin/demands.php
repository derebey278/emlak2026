<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();
global $nusaybinNeighborhoods;

$rooms = ['1+1', '2+1', '3+1', '4+1', '5+1', 'Dukkan', 'Arsa'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string) post('action');

    if ($action === 'create') {
        require_fields(['full_name', 'phone', 'status']);
        if (!in_array(post('status'), ['Kiralik', 'Satilik'], true)) {
            flash('error', 'Talep tipi gecersiz.');
            redirect('demands.php');
        }
        if (post('neighborhood') !== '' && !in_array(post('neighborhood'), $nusaybinNeighborhoods, true)) {
            flash('error', 'Mahalle bilgisi gecersiz.');
            redirect('demands.php');
        }
        if (post('room_count') !== '' && !in_array(post('room_count'), $rooms, true)) {
            flash('error', 'Oda bilgisi gecersiz.');
            redirect('demands.php');
        }
        db()->prepare('INSERT INTO demands (full_name, phone, status, neighborhood, room_count, max_price, note, source_listing_id, created_at) VALUES (:full_name, :phone, :status, :neighborhood, :room_count, :max_price, :note, NULL, NOW())')->execute([
            'full_name' => trim((string) post('full_name')),
            'phone' => trim((string) post('phone')),
            'status' => post('status'),
            'neighborhood' => post('neighborhood') ?: null,
            'room_count' => post('room_count') ?: null,
            'max_price' => post('max_price') !== '' ? (int) post('max_price') : null,
            'note' => trim((string) post('note')),
        ]);
        flash('success', 'Musteri talebi eklendi.');
        redirect('demands.php');
    }

    if ($action === 'match' && post('demand_id') && post('listing_id')) {
        db()->prepare('INSERT IGNORE INTO demand_listing_matches (demand_id, listing_id, created_at) VALUES (:demand_id, :listing_id, NOW())')->execute([
            'demand_id' => (int) post('demand_id'),
            'listing_id' => (int) post('listing_id'),
        ]);
        flash('success', 'Talep ile ilan eslestirildi.');
        redirect('demands.php?id=' . (int) post('demand_id'));
    }

    if ($action === 'delete' && post('id')) {
        db()->prepare('DELETE FROM demands WHERE id = :id')->execute(['id' => (int) post('id')]);
        flash('success', 'Talep silindi.');
        redirect('demands.php');
    }
}

$selectedDemand = null;
$matches = [];
$matchedIds = [];
if (!empty($_GET['id'])) {
    $stmt = db()->prepare('SELECT * FROM demands WHERE id = :id');
    $stmt->execute(['id' => (int) $_GET['id']]);
    $selectedDemand = $stmt->fetch() ?: null;
    if ($selectedDemand) {
        $matches = suitable_listings_for_demand($selectedDemand);
        $matchedStmt = db()->prepare('SELECT listing_id FROM demand_listing_matches WHERE demand_id = :id');
        $matchedStmt->execute(['id' => (int) $selectedDemand['id']]);
        $matchedIds = array_map('intval', array_column($matchedStmt->fetchAll(), 'listing_id'));
    }
}

$demands = db()->query('SELECT * FROM demands ORDER BY created_at DESC')->fetchAll();
include __DIR__ . '/../includes/admin-header.php';
?>
<div class="admin-title">
    <div>
        <h1>Musteri talepleri</h1>
        <p>Musteri aramalarini kaydedin, uygun ilanlari gorun ve eslestirme yapin.</p>
    </div>
</div>

<div class="panel">
    <h2>Yeni talep ekle</h2>
    <form method="post" class="form-grid">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="create">
        <input name="full_name" placeholder="Musteri ad soyad" required>
        <input name="phone" placeholder="Telefon numarasi" required>
        <select name="status" required>
            <option value="">Talep tipi</option>
            <option value="Kiralik">Kiralik</option>
            <option value="Satilik">Satilik</option>
        </select>
        <select name="neighborhood">
            <option value="">Mahalle fark etmez</option>
            <?php foreach ($nusaybinNeighborhoods as $n): ?><option value="<?= e($n) ?>"><?= e($n) ?></option><?php endforeach; ?>
        </select>
        <select name="room_count">
            <option value="">Oda fark etmez</option>
            <?php foreach ($rooms as $room): ?><option value="<?= e($room) ?>"><?= e($room) ?></option><?php endforeach; ?>
        </select>
        <input type="number" name="max_price" placeholder="Maksimum butce">
        <textarea class="full" name="note" placeholder="Musterinin notu, tasinma tarihi, ozel kriterleri"></textarea>
        <button type="submit">Talebi kaydet</button>
    </form>
</div>

<h2>Talep listesi</h2>
<table class="table">
    <tr><th>Musteri</th><th>Kriter</th><th>Uygunluk</th><th>Islem</th></tr>
    <?php foreach ($demands as $demand): $count = match_count_for_demand($demand); ?>
        <tr>
            <td><strong><?= e($demand['full_name']) ?></strong><br><small><?= e($demand['phone']) ?></small></td>
            <td>
                <?= e($demand['status']) ?>, <?= e($demand['room_count'] ?: 'oda fark etmez') ?>, <?= e($demand['neighborhood'] ?: 'mahalle fark etmez') ?>
                <?php if ($demand['max_price']): ?><br><small>Butce: <?= money_fmt($demand['max_price']) ?></small><?php endif; ?>
                <?php if ($demand['note']): ?><br><small><?= e($demand['note']) ?></small><?php endif; ?>
            </td>
            <td>
                <?php if ($count > 0): ?>
                    <span class="tag blue"><?= $count ?> uygun ilan</span>
                <?php else: ?>
                    <span class="tag yellow">Takipte</span>
                <?php endif; ?>
            </td>
            <td class="actions">
                <a class="btn" href="demands.php?id=<?= (int) $demand['id'] ?>">Ilanlari gor</a>
                <form method="post" onsubmit="return confirm('Bu talebi silmek istiyor musunuz?')">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?= (int) $demand['id'] ?>">
                    <button class="danger-btn" type="submit">Sil</button>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

<?php if ($selectedDemand): ?>
    <h2><?= e($selectedDemand['full_name']) ?> icin uygun ilanlar</h2>
    <div class="grid">
        <?php foreach ($matches as $listing): ?>
            <div class="panel match-card">
                <span class="tag <?= in_array((int) $listing['id'], $matchedIds, true) ? 'blue' : '' ?>"><?= in_array((int) $listing['id'], $matchedIds, true) ? 'Eslesti' : 'Uygun' ?></span>
                <h3><?= e($listing['title']) ?></h3>
                <p><?= e($listing['status']) ?>, <?= e($listing['neighborhood']) ?>, <?= e($listing['room_count']) ?></p>
                <p><strong><?= money_fmt($listing['price']) ?></strong></p>
                <form method="post">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="match">
                    <input type="hidden" name="demand_id" value="<?= (int) $selectedDemand['id'] ?>">
                    <input type="hidden" name="listing_id" value="<?= (int) $listing['id'] ?>">
                    <button type="submit"><?= in_array((int) $listing['id'], $matchedIds, true) ? 'Tekrar eslestir' : 'Bu ilanla eslestir' ?></button>
                </form>
            </div>
        <?php endforeach; ?>
        <?php if ($matches === []): ?><div class="panel">Bu talebe su an uygun ilan yok. Yeni ilan girildiginde buradan kontrol edebilirsiniz.</div><?php endif; ?>
    </div>
<?php endif; ?>
<?php include __DIR__ . '/../includes/admin-footer.php'; ?>
