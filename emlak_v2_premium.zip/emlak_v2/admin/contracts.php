<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();
global $nusaybinNeighborhoods;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    require_fields(['neighborhood', 'tenant_name', 'tenant_tc', 'tenant_phone', 'landlord_name', 'landlord_tc', 'landlord_phone', 'property_address', 'monthly_rent', 'deposit', 'start_date', 'end_date', 'payment_day']);
    if (!in_array(post('neighborhood'), $nusaybinNeighborhoods, true)) {
        flash('error', 'Gecersiz mahalle secildi.');
        redirect('contracts.php');
    }
    if ((int) post('monthly_rent') <= 0 || (int) post('deposit') < 0) {
        flash('error', 'Kira pozitif, depozito sifir veya pozitif olmalidir.');
        redirect('contracts.php');
    }
    if (!is_valid_date((string) post('start_date')) || !is_valid_date((string) post('end_date')) || post('end_date') <= post('start_date')) {
        flash('error', 'Sozlesme tarihleri gecersiz.');
        redirect('contracts.php');
    }
    if ((int) post('payment_day') < 1 || (int) post('payment_day') > 31) {
        flash('error', 'Odeme gunu 1-31 arasinda olmalidir.');
        redirect('contracts.php');
    }
    $annualRent = (int) post('annual_rent');
    if ($annualRent <= 0) {
        $annualRent = (int) post('monthly_rent') * 12;
    }

    $stmt = db()->prepare('INSERT INTO rental_contracts (
        listing_id, city, district, neighborhood, street, door_no, electric_subscriber_no, water_subscriber_no, gas_subscriber_no,
        tenant_name, tenant_tc, tenant_phone, tenant_address, landlord_name, landlord_tc, landlord_phone, landlord_address,
        property_address, monthly_rent, deposit, rental_period, annual_rent, usage_type, property_condition, fixtures,
        start_date, end_date, payment_day, special_terms, created_at
    ) VALUES (
        :listing_id, "Mardin", "Nusaybin", :neighborhood, :street, :door_no, :electric_subscriber_no, :water_subscriber_no, :gas_subscriber_no,
        :tenant_name, :tenant_tc, :tenant_phone, :tenant_address, :landlord_name, :landlord_tc, :landlord_phone, :landlord_address,
        :property_address, :monthly_rent, :deposit, :rental_period, :annual_rent, :usage_type, :property_condition, :fixtures,
        :start_date, :end_date, :payment_day, :special_terms, NOW()
    )');
    $stmt->execute([
        'listing_id' => post('listing_id') ?: null,
        'neighborhood' => post('neighborhood'),
        'street' => post('street'),
        'door_no' => post('door_no'),
        'electric_subscriber_no' => post('electric_subscriber_no'),
        'water_subscriber_no' => post('water_subscriber_no'),
        'gas_subscriber_no' => post('gas_subscriber_no'),
        'tenant_name' => post('tenant_name'),
        'tenant_tc' => post('tenant_tc'),
        'tenant_phone' => post('tenant_phone'),
        'tenant_address' => post('tenant_address'),
        'landlord_name' => post('landlord_name'),
        'landlord_tc' => post('landlord_tc'),
        'landlord_phone' => post('landlord_phone'),
        'landlord_address' => post('landlord_address'),
        'property_address' => post('property_address'),
        'monthly_rent' => (int) post('monthly_rent'),
        'deposit' => (int) post('deposit'),
        'rental_period' => post('rental_period') ?: '1 YIL',
        'annual_rent' => $annualRent,
        'usage_type' => post('usage_type') ?: 'MESKEN',
        'property_condition' => post('property_condition') ?: 'BOS',
        'fixtures' => post('fixtures'),
        'start_date' => post('start_date'),
        'end_date' => post('end_date'),
        'payment_day' => (int) post('payment_day'),
        'special_terms' => post('special_terms'),
    ]);
    header('Location: contracts.php?saved=1');
    exit;
}

$listings = db()->query('SELECT id, title FROM listings WHERE status = "Kiralik" ORDER BY created_at DESC')->fetchAll();
$contracts = db()->query('SELECT * FROM rental_contracts ORDER BY end_date ASC')->fetchAll();
include __DIR__ . '/../includes/admin-header.php';
?>
<h1>Kira sozlesmesi takibi</h1>
<?php if (!empty($_GET['saved'])): ?><div class="notice">Kira sozlesmesi kaydedildi.</div><?php endif; ?>

<div class="panel">
    <h2>Yeni kira sozlesmesi olustur</h2>
    <form method="post" class="form-grid">
        <?= csrf_field() ?>
        <select class="full" name="listing_id">
            <option value="">Ilan secmeden sozlesme olustur</option>
            <?php foreach ($listings as $listing): ?><option value="<?= (int) $listing['id'] ?>"><?= e($listing['title']) ?></option><?php endforeach; ?>
        </select>
        <select name="neighborhood" required>
            <?php foreach ($nusaybinNeighborhoods as $n): ?><option value="<?= e($n) ?>"><?= e($n) ?></option><?php endforeach; ?>
        </select>
        <input name="street" placeholder="Cadde / sokak">
        <input name="door_no" placeholder="Dis kapi / daire no">
        <input name="electric_subscriber_no" placeholder="Elektrik abone no">
        <input name="water_subscriber_no" placeholder="Su abone no">
        <input name="gas_subscriber_no" placeholder="Dogalgaz abone no">
        <input name="tenant_name" placeholder="Kiraci ad soyad" required>
        <input name="tenant_tc" placeholder="Kiraci TC kimlik no" required>
        <input name="tenant_phone" placeholder="Kiraci telefon" required>
        <textarea name="tenant_address" placeholder="Kiraci adresi"></textarea>
        <input name="landlord_name" placeholder="Kiraya veren ad soyad" required>
        <input name="landlord_tc" placeholder="Kiraya veren TC kimlik no" required>
        <input name="landlord_phone" placeholder="Kiraya veren telefon" required>
        <textarea name="landlord_address" placeholder="Kiraya veren adresi"></textarea>
        <input type="number" name="monthly_rent" placeholder="Aylik kira bedeli" required>
        <input type="number" name="deposit" placeholder="Depozito" required>
        <input name="rental_period" value="1 YIL" placeholder="Kira suresi">
        <input type="number" name="annual_rent" placeholder="Yillik kira bedeli otomatik bos birakilabilir">
        <input name="usage_type" value="MESKEN" placeholder="Kullanim sekli">
        <input name="property_condition" value="BOS" placeholder="Kiralanan durumu">
        <input type="date" name="start_date" required>
        <input type="date" name="end_date" required>
        <input type="number" min="1" max="31" name="payment_day" placeholder="Odeme gunu" required>
        <textarea class="full" name="property_address" placeholder="Kiralanan tasinmaz adresi" required></textarea>
        <textarea class="full" name="fixtures" placeholder="Kiralananla birlikte teslim edilen demirbaslar"></textarea>
        <textarea class="full" name="special_terms" placeholder="Ozel sartlar"></textarea>
        <button class="full" type="submit">Sozlesmeyi kaydet</button>
    </form>
</div>

<h2>Sozlesmeler</h2>
<table class="table">
    <tr><th>Kiraci</th><th>Kiraya veren</th><th>Baslangic</th><th>Bitis</th><th>Durum</th><th>Islem</th></tr>
    <?php foreach ($contracts as $contract): $status = contract_status($contract); ?>
        <tr>
            <td><?= e($contract['tenant_name']) ?><br><small>TC: <?= e($contract['tenant_tc']) ?>, Tel: <?= e($contract['tenant_phone']) ?></small></td>
            <td><?= e($contract['landlord_name']) ?><br><small>TC: <?= e($contract['landlord_tc']) ?>, Tel: <?= e($contract['landlord_phone']) ?></small></td>
            <td><?= e($contract['start_date']) ?></td>
            <td><?= e($contract['end_date']) ?></td>
            <td><span class="tag <?= e($status['class']) ?>"><?= e($status['label']) ?>, <?= (int) $status['days_left'] ?> gun</span></td>
            <td><a class="btn" href="contract_print.php?id=<?= (int) $contract['id'] ?>" target="_blank">PDF / yazdir</a></td>
        </tr>
    <?php endforeach; ?>
</table>
<?php include __DIR__ . '/../includes/admin-footer.php'; ?>
