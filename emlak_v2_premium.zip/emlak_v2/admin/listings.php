<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();
global $nusaybinNeighborhoods;

$rooms = ['1+1', '2+1', '3+1', '4+1', '5+1', 'Dükkan', 'Arsa'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string) post('action', 'save');
    $id = (int) post('id', 0);

    if ($action === 'toggle' && $id > 0) {
        $listing = find_listing_admin($id);
        if ($listing) {
            db()->prepare('UPDATE listings SET is_active = :active, updated_at = NOW() WHERE id = :id')->execute([
                'active' => (int) $listing['is_active'] === 1 ? 0 : 1,
                'id' => $id,
            ]);
            flash('success', (int) $listing['is_active'] === 1 ? 'İlan pasife alındı.' : 'İlan aktife alındı.');
        }
        redirect('listings.php');
    }

    if ($action === 'delete' && $id > 0) {
        try {
            db()->prepare('DELETE FROM listings WHERE id = :id')->execute(['id' => $id]);
            flash('success', 'İlan silindi.');
        } catch (Throwable $e) {
            flash('error', 'Bu ilan talep veya sözleşme kayıtlarına bağlı; pasife alabilirsiniz.');
        }
        redirect('listings.php');
    }

    require_fields(['title', 'status', 'neighborhood', 'room_count', 'price', 'gross_m2', 'description']);
    if (!in_array(post('status'), ['Kiralik', 'Satilik'], true)) {
        flash('error', 'Geçersiz ilan tipi.'); redirect('listings.php');
    }

    $existingImages = array_values(array_filter($_POST['keep_images'] ?? []));
    $urlImages = array_filter(array_map('trim', explode("\n", (string) post('image_urls'))));
    $uploadedImages = upload_listing_images('photos');
    $images = array_values(array_unique(array_merge($existingImages, $urlImages, $uploadedImages)));

    $params = [
        'title'       => trim((string) post('title')),
        'status'      => post('status'),
        'neighborhood'=> post('neighborhood'),
        'room_count'  => post('room_count'),
        'price'       => (int) post('price'),
        'gross_m2'    => (int) post('gross_m2'),
        'net_m2'      => (int) post('net_m2'),
        'floor'       => trim((string) post('floor')),
        'building_age'=> trim((string) post('building_age')),
        'heating'     => trim((string) post('heating')),
        'description' => trim((string) post('description')),
        'images'      => json_encode($images, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
        'is_featured' => post('is_featured') ? 1 : 0,
        'is_active'   => post('is_active') ? 1 : 0,
    ];

    if ($id > 0) {
        $params['id'] = $id;
        db()->prepare('UPDATE listings SET title=:title, status=:status, neighborhood=:neighborhood, room_count=:room_count, price=:price, gross_m2=:gross_m2, net_m2=:net_m2, floor=:floor, building_age=:building_age, heating=:heating, description=:description, images=:images, is_featured=:is_featured, is_active=:is_active, updated_at=NOW() WHERE id=:id')->execute($params);
        flash('success', 'İlan güncellendi.');
    } else {
        db()->prepare('INSERT INTO listings (title, status, city, district, neighborhood, room_count, price, gross_m2, net_m2, floor, building_age, heating, description, images, is_featured, is_active, created_at, updated_at) VALUES (:title, :status, "Mardin", "Nusaybin", :neighborhood, :room_count, :price, :gross_m2, :net_m2, :floor, :building_age, :heating, :description, :images, :is_featured, :is_active, NOW(), NOW())')->execute($params);
        flash('success', 'Yeni ilan kaydedildi.');
    }
    redirect('listings.php');
}

$editListing = null;
if (!empty($_GET['edit'])) {
    $editListing = find_listing_admin((int) $_GET['edit']);
}
$editImages = $editListing ? listing_images($editListing) : [];
$listings = db()->query('SELECT * FROM listings ORDER BY is_active DESC, created_at DESC')->fetchAll();
include __DIR__ . '/../includes/admin-header.php';
?>
<div class="admin-title">
    <div>
        <h1>İlan Yönetimi</h1>
        <p>Resimleri yükleyin, ilanları düzenleyin, vitrine alın, pasife çekin veya silin.</p>
    </div>
    <a class="btn sm secondary" href="listings.php">Yeni İlan Formu</a>
</div>

<div class="panel" style="margin-bottom:24px">
    <h2><?= $editListing ? 'İlanı Düzenle' : 'Yeni İlan Ekle' ?></h2>
    <form method="post" enctype="multipart/form-data" class="form-grid">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= $editListing ? (int)$editListing['id'] : 0 ?>">

        <div class="form-group full">
            <label>İlan Başlığı *</label>
            <input name="title" value="<?= e($editListing['title'] ?? '') ?>" placeholder="İlan başlığı" required>
        </div>

        <!-- AI ASSISTANT -->
        <div class="ai-panel full">
            <div class="ai-panel-header">
                <span class="ai-badge">✨ AI</span>
                <span style="font-size:13px;color:var(--muted)">Başlık doldurulduktan sonra AI ile açıklama oluşturun</span>
            </div>
            <div style="display:flex;gap:10px;align-items:center">
                <button type="button" class="btn sm outline" onclick="generateDescription()">Açıklama Oluştur</button>
                <span id="ai-loading">⏳ Oluşturuluyor…</span>
            </div>
        </div>

        <div class="form-group">
            <label>İlan Tipi *</label>
            <select name="status" required>
                <option value="">Seçin</option>
                <option value="Kiralik"<?= selected($editListing['status'] ?? '', 'Kiralik') ?>>Kiralık</option>
                <option value="Satilik"<?= selected($editListing['status'] ?? '', 'Satilik') ?>>Satılık</option>
            </select>
        </div>
        <div class="form-group">
            <label>Mahalle *</label>
            <select name="neighborhood" required>
                <option value="">Seçin</option>
                <?php foreach ($nusaybinNeighborhoods as $n): ?>
                    <option value="<?= e($n) ?>"<?= selected($editListing['neighborhood'] ?? '', $n) ?>><?= e($n) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label>Oda Sayısı *</label>
            <select name="room_count" required>
                <option value="">Seçin</option>
                <?php foreach ($rooms as $r): ?>
                    <option value="<?= e($r) ?>"<?= selected($editListing['room_count'] ?? '', $r) ?>><?= e($r) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label>Fiyat (TL) *</label>
            <input type="number" name="price" value="<?= (int)($editListing['price'] ?? 0) ?: '' ?>" placeholder="Fiyat" required>
        </div>
        <div class="form-group">
            <label>Brüt m² *</label>
            <input type="number" name="gross_m2" value="<?= (int)($editListing['gross_m2'] ?? 0) ?: '' ?>" placeholder="Brüt m²" required>
        </div>
        <div class="form-group">
            <label>Net m²</label>
            <input type="number" name="net_m2" value="<?= (int)($editListing['net_m2'] ?? 0) ?: '' ?>" placeholder="Net m²">
        </div>
        <div class="form-group">
            <label>Kat</label>
            <input name="floor" value="<?= e($editListing['floor'] ?? '') ?>" placeholder="Örn: 3/5">
        </div>
        <div class="form-group">
            <label>Bina Yaşı</label>
            <input name="building_age" value="<?= e($editListing['building_age'] ?? '') ?>" placeholder="Örn: 5 yıl">
        </div>
        <div class="form-group">
            <label>Isıtma</label>
            <input name="heating" value="<?= e($editListing['heating'] ?? '') ?>" placeholder="Doğalgaz, Merkezi…">
        </div>

        <div class="form-group full">
            <label>Açıklama *</label>
            <textarea name="description" id="description-textarea" rows="5" required><?= e($editListing['description'] ?? '') ?></textarea>
        </div>

        <!-- IMAGE MANAGER -->
        <?php if ($editImages !== []): ?>
        <div class="form-group full">
            <label>Mevcut Resimler (Kaldırmak için işareti kaldırın)</label>
            <div class="image-manager">
                <?php foreach ($editImages as $img): ?>
                <label>
                    <img src="<?= strpos($img, 'http') === 0 ? $img : '../public/'.$img ?>" alt="">
                    <input type="checkbox" name="keep_images[]" value="<?= e($img) ?>" checked style="width:auto">
                    <small style="word-break:break-all;font-size:10px;color:var(--muted)"><?= e(basename($img)) ?></small>
                </label>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <div class="form-group full">
            <label>Yeni Resim Yükle (JPG/PNG/WEBP, maks. 5 MB)</label>
            <input type="file" name="photos[]" multiple accept="image/jpeg,image/png,image/webp">
        </div>
        <div class="form-group full">
            <label>Resim URL'leri (her satıra bir adet)</label>
            <textarea name="image_urls" rows="3" placeholder="https://…"></textarea>
        </div>

        <div style="display:flex;gap:14px;align-items:center">
            <label style="display:flex;align-items:center;gap:7px;font-size:14px;cursor:pointer">
                <input type="checkbox" name="is_featured" value="1"<?= checked((bool)($editListing['is_featured'] ?? false)) ?> style="width:auto">
                Vitrine Çıkar
            </label>
            <label style="display:flex;align-items:center;gap:7px;font-size:14px;cursor:pointer">
                <input type="checkbox" name="is_active" value="1"<?= checked((bool)($editListing['is_active'] ?? true)) ?> style="width:auto">
                Aktif
            </label>
        </div>

        <div style="display:flex;gap:10px">
            <button type="submit"><?= $editListing ? 'Güncelle' : 'İlanı Kaydet' ?></button>
            <?php if ($editListing): ?><a class="btn secondary" href="listings.php">İptal</a><?php endif; ?>
        </div>
    </form>
</div>

<!-- LISTINGS TABLE -->
<table class="table">
    <tr><th>İlan</th><th>Tip</th><th>Mahalle</th><th>Fiyat</th><th>m²</th><th>Görüntü</th><th>Durum</th><th>İşlem</th></tr>
    <?php foreach ($listings as $listing): ?>
    <tr>
        <td><strong><?= e($listing['title']) ?></strong><br><small><?= e(date('d.m.Y', strtotime($listing['created_at']))) ?></small></td>
        <td><span class="tag <?= $listing['status'] === 'Kiralik' ? 'blue' : 'yellow' ?>"><?= e($listing['status']) ?></span></td>
        <td><?= e($listing['neighborhood']) ?></td>
        <td><strong><?= money_fmt($listing['price']) ?></strong></td>
        <td><?= (int)$listing['gross_m2'] ?> m²<?= $listing['net_m2'] ?? 0 ? '<br><small>Net: '.(int)$listing['net_m2'].' m²</small>' : '' ?></td>
        <td><?= (int)$listing['view_count'] ?></td>
        <td>
            <?= $listing['is_active'] ? '<span class="tag green">Aktif</span>' : '<span class="tag red">Pasif</span>' ?>
            <?= $listing['is_featured'] ? ' <span class="tag">⭐</span>' : '' ?>
        </td>
        <td class="actions">
            <a class="btn sm" href="listings.php?edit=<?= (int)$listing['id'] ?>">Düzenle</a>
            <form method="post"><form method="post"><
                <?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int)$listing['id'] ?>">
                <button class="btn sm secondary" type="submit"><?= $listing['is_active'] ? 'Pasife Al' : 'Aktife Al' ?></button>
            </form>
            <form method="post" onsubmit="return confirm('Silmek istediğinize emin misiniz?')">
                <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$listing['id'] ?>">
                <button class="btn danger-btn sm" type="submit">Sil</button>
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

<script>
async function generateDescription() {
    const title = document.querySelector('input[name="title"]').value.trim();
    const status = document.querySelector('select[name="status"]').value;
    const neighborhood = document.querySelector('select[name="neighborhood"]').value;
    const rooms = document.querySelector('select[name="room_count"]').value;
    const price = document.querySelector('input[name="price"]').value;
    const m2 = document.querySelector('input[name="gross_m2"]').value;
    const floor = document.querySelector('input[name="floor"]').value;
    const heating = document.querySelector('input[name="heating"]').value;

    if (!title) { alert('Lütfen önce ilan başlığını girin.'); return; }

    document.getElementById('ai-loading').style.display = 'inline';

    const prompt = `Sen Türkçe konuşan bir emlak uzmanısın. Aşağıdaki bilgilerle profesyonel ve çekici bir Türkçe ilan açıklaması yaz (maksimum 4 cümle, abartısız, samimi):
Başlık: ${title}
Tip: ${status === 'Kiralik' ? 'Kiralık' : 'Satılık'}
Mahalle: ${neighborhood}, Nusaybin/Mardin
Oda: ${rooms}, Brüt: ${m2} m²
${floor ? 'Kat: ' + floor : ''}${heating ? ', Isıtma: ' + heating : ''}
Fiyat: ${Number(price).toLocaleString('tr')} TL`;

    try {
        const res = await fetch('https://api.anthropic.com/v1/messages', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: 'claude-sonnet-4-20250514',
                max_tokens: 400,
                messages: [{ role: 'user', content: prompt }]
            })
        });
        const data = await res.json();
        const text = data.content?.map(c => c.text || '').join('').trim();
        if (text) {
            document.getElementById('description-textarea').value = text;
        } else {
            alert('AI yanıt vermedi. Lütfen tekrar deneyin.');
        }
    } catch(e) {
        alert('Bağlantı hatası: ' + e.message);
    } finally {
        document.getElementById('ai-loading').style.display = 'none';
    }
}
</script>
<?php include __DIR__ . '/../includes/admin-footer.php'; ?>
