<?php
require_once __DIR__ . '/../includes/functions.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

if (!empty($_SESSION['admin'])) { header('Location: index.php'); exit; }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = trim((string)($_POST['username'] ?? ''));
    $pass = (string)($_POST['password'] ?? '');
    if ($user === ADMIN_USER && $pass === ADMIN_PASS) {
        $_SESSION['admin'] = true;
        $_SESSION['admin_login_time'] = time();
        header('Location: index.php'); exit;
    }
    $error = 'Kullanıcı adı veya şifre hatalı.';
    sleep(1);
}
?>
<!doctype html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Giriş | <?= e(APP_NAME) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="../public/assets/styles.css">
    <style>
        body { display:flex; align-items:center; justify-content:center; min-height:100vh; background: radial-gradient(circle at 30% 40%, rgba(201,163,90,.06), transparent 60%), var(--paper); }
        .login-box { width:100%; max-width:400px; padding:20px; }
        .login-card { background:var(--paper-2); border:1px solid var(--line); border-radius:var(--radius-lg); padding:36px; box-shadow:var(--shadow); }
        .login-brand { text-align:center; margin-bottom:28px; }
        .login-brand-name { font-family:'Playfair Display',serif; font-size:22px; color:var(--gold-light); }
        .login-brand-sub { font-size:13px; color:var(--muted); margin-top:4px; }
        .login-divider { height:1px; background:linear-gradient(90deg,transparent,var(--gold),transparent); opacity:.3; margin:20px 0; }
    </style>
</head>
<body class="admin-body">
<div class="login-box">
    <div class="login-card">
        <div class="login-brand">
            <div style="font-size:28px;margin-bottom:8px">🏢</div>
            <div class="login-brand-name"><?= e(APP_NAME) ?></div>
            <div class="login-brand-sub">Yönetici Girişi</div>
        </div>
        <div class="login-divider"></div>
        <?php if ($error): ?><div class="notice error"><?= e($error) ?></div><?php endif; ?>
        <form method="post" style="display:grid;gap:12px">
            <div class="form-group">
                <label>Kullanıcı Adı</label>
                <input name="username" autocomplete="username" autofocus>
            </div>
            <div class="form-group">
                <label>Şifre</label>
                <input type="password" name="password" autocomplete="current-password">
            </div>
            <button type="submit" style="margin-top:8px">Giriş Yap</button>
        </form>
    </div>
</div>
</body>
</html>
