<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';

function assert_true(bool $condition, string $message): void
{
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

assert_true(e('<test>') === '&lt;test&gt;', 'HTML escaping failed.');
assert_true(money_fmt(14500) === '14.500 TL', 'Money formatting failed.');
assert_true(selected('Mardin', 'Mardin') === ' selected', 'Selected helper failed.');
assert_true(selected('Mardin', 'Nusaybin') === '', 'Selected helper mismatch failed.');
assert_true(is_valid_date('2026-05-26') === true, 'Valid date rejected.');
assert_true(is_valid_date('2026-02-31') === false, 'Invalid date accepted.');

$listing = ['images' => '["a.jpg","b.jpg"]'];
assert_true(listing_images($listing) === ['a.jpg', 'b.jpg'], 'Listing images parsing failed.');

$today = new DateTimeImmutable('today');
$newContract = [
    'created_at' => $today->format('Y-m-d H:i:s'),
    'end_date' => $today->modify('+10 days')->format('Y-m-d'),
];
$newStatus = contract_status($newContract);
assert_true($newStatus['class'] === 'blue', 'New contract should be blue.');

$endingContract = [
    'created_at' => $today->modify('-20 days')->format('Y-m-d H:i:s'),
    'end_date' => $today->modify('+10 days')->format('Y-m-d'),
];
$endingStatus = contract_status($endingContract);
assert_true($endingStatus['class'] === 'red', 'Ending contract should be red.');

$normalContract = [
    'created_at' => $today->modify('-20 days')->format('Y-m-d H:i:s'),
    'end_date' => $today->modify('+90 days')->format('Y-m-d'),
];
$normalStatus = contract_status($normalContract);
assert_true($normalStatus['class'] === 'yellow', 'Normal contract should be yellow.');

echo "Smoke tests passed.\n";
