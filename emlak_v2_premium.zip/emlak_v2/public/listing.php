<?php
require_once __DIR__ . '/../includes/functions.php';
$office = office_settings();
$id = (int) ($_GET['id'] ?? 0);
$listing = $id > 0 ? find_listing($id) : null;
if (!$listing) { header('Location: index.php'); exit; }
db()->prepare('UPDATE listings SET view_count = view_count + 1 WHERE id = :id')->execute(['id' => $id]);
$images = listing_images($listing);
?>
<!doctype html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($listing['title']) ?> | <?= e($office['name']) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="assets/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css">
</head>
<body class="public-body">

<header class="topbar">
    <div class="wrap topbar-inner">
        <a class="brand" href="index.php">
            <?php if (!empty($office['logo_path'])): ?>
                <img class="brand-logo" src="<?= e($office['logo_path']) ?>" alt="">
            <?php else: ?>
                <span class="brand-dot"></span>
            <?php endif; ?>
            <?= e($office['name']) ?>
        </a>
        <nav class="navlinks">
            <a href="index.php">← Tüm İlanlar</a>
        </nav>
    </div>
</header>

<main>
<div class="wrap">
    <div class="detail-top">
        <div>
            <div class="breadcrumb"><a href="index.php">Ana Sayfa</a> / <a href="index.php?status=<?= e($listing['status']) ?>"><?= e($listing['status']) ?></a> / <?= e($listing['neighborhood']) ?></div>
            <h1><?= e($listing['title']) ?></h1>
            <div style="color:var(--muted);margin-top:8px;font-size:15px">📍 <?= e($listing['neighborhood']) ?>, <?= e($listing['district']) ?> / <?= e($listing['city']) ?></div>
        </div>
        <div class="detail-price panel">
            <span><?= $listing['status'] === 'Kiralik' ? 'Aylık Kira' : 'Satış Fiyatı' ?></span>
            <strong><?= money_fmt($listing['price']) ?></strong>
            <?php if ($listing['status'] === 'Kiralik'): ?><small style="color:var(--muted)">+ Depozito müzakereye açık</small><?php endif; ?>
        </div>
    </div>

    <div class="detail-layout">
        <!-- LEFT -->
        <div>
            <!-- GALLERY -->
            <div class="sahibinden-gallery">
                <img id="main-img" src="<?= e($images[0]) ?>" alt="<?= e($listing['title']) ?>">
                <?php if (count($images) > 1): ?>
                <div class="gallery-thumbs">
                    <?php foreach ($images as $i => $img): ?>
                        <img src="<?= e($img) ?>" alt="" class="<?= $i === 0 ? 'active' : '' ?>" onclick="switchImg(this, '<?= e($img) ?>')">
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- SPECS -->
            <div class="panel" style="margin-top:16px">
                <h2 style="font-family:'Playfair Display',serif;color:var(--gold-dark);margin:0 0 14px">İlan Detayları</h2>
                <div class="fact-grid">
                    <div class="fact-item"><span>Oda Sayısı</span><strong><?= e($listing['room_count']) ?></strong></div>
                    <div class="fact-item"><span>Brüt m²</span><strong><?= (int)$listing['gross_m2'] ?> m²</strong></div>
                    <?php if (!empty($listing['net_m2']) && (int)$listing['net_m2'] > 0): ?>
                    <div class="fact-item"><span>Net m²</span><strong><?= (int)$listing['net_m2'] ?> m²</strong></div>
                    <?php endif; ?>
                    <?php if (!empty($listing['floor'])): ?>
                    <div class="fact-item"><span>Kat</span><strong><?= e($listing['floor']) ?></strong></div>
                    <?php endif; ?>
                    <?php if (!empty($listing['building_age'])): ?>
                    <div class="fact-item"><span>Bina Yaşı</span><strong><?= e($listing['building_age']) ?></strong></div>
                    <?php endif; ?>
                    <?php if (!empty($listing['heating'])): ?>
                    <div class="fact-item"><span>Isıtma</span><strong><?= e($listing['heating']) ?></strong></div>
                    <?php endif; ?>
                    <div class="fact-item"><span>Tip</span><strong><?= e($listing['status']) ?></strong></div>
                    <div class="fact-item"><span>Görüntülenme</span><strong><?= (int)$listing['view_count'] ?></strong></div>
                </div>
            </div>

            <!-- DESCRIPTION -->
            <?php if (!empty($listing['description'])): ?>
            <div class="panel" style="margin-top:16px">
                <h2 style="font-family:'Playfair Display',serif;color:var(--gold-dark);margin:0 0 10px">Açıklama</h2>
                <p style="color:var(--muted);line-height:1.75;margin:0"><?= nl2br(e($listing['description'])) ?></p>
            </div>
            <?php endif; ?>

            <!-- MAP -->
            <div class="panel" style="margin-top:16px">
                <h2 style="font-family:'Playfair Display',serif;color:var(--gold-dark);margin:0 0 12px">Konum</h2>
                <p style="font-size:13px;color:var(--muted);margin:0 0 10px">📍 <?= e($listing['neighborhood']) ?>, Nusaybin / Mardin — <em>Kesin konum için ofisi arayın.</em></p>
                <div id="listing-map"></div>
            </div>
        </div>

        <!-- SIDEBAR -->
        <div class="detail-sidebar">
            <div class="panel panel-gold">
                <h2 style="font-family:'Playfair Display',serif;color:var(--gold-dark);margin:0 0 6px"><?= e($office['name']) ?></h2>
                <p style="color:var(--muted);font-size:14px;margin:0 0 10px"><?= e($office['address']) ?></p>
                <a class="phone-line" href="tel:<?= e($office['phone']) ?>"><?= e($office['phone']) ?></a>
                <div class="contact-actions">
                    <a class="btn" href="tel:<?= e($office['phone']) ?>">📞 Ara</a>
                    <?php if (!empty($office['whatsapp'])): ?>
                    <a class="btn secondary" href="https://wa.me/<?= e($office['whatsapp']) ?>?text=Merhaba%2C+<?= rawurlencode($listing['title']) ?>+ilanı+hakkında+bilgi+almak+istiyorum." target="_blank">💬 WhatsApp</a>
                    <?php endif; ?>
                </div>
                <a class="btn outline" href="request.php" style="width:100%;margin-top:10px;display:flex">📋 Talep Oluştur</a>
            </div>

            <div class="panel">
                <h2 style="font-family:'Playfair Display',serif;font-size:16px;margin:0 0 12px">İlan Özeti</h2>
                <dl class="spec-list">
                    <div><dt>Durum</dt><dd><?= e($listing['status']) ?></dd></div>
                    <div><dt>Mahalle</dt><dd><?= e($listing['neighborhood']) ?></dd></div>
                    <div><dt>Oda</dt><dd><?= e($listing['room_count']) ?></dd></div>
                    <div><dt>Brüt m²</dt><dd><?= (int)$listing['gross_m2'] ?> m²</dd></div>
                    <div><dt>Fiyat</dt><dd><?= money_fmt($listing['price']) ?></dd></div>
                    <div><dt>İlan Tarihi</dt><dd><?= date('d.m.Y', strtotime($listing['created_at'])) ?></dd></div>
                </dl>
            </div>
        </div>
    </div>
</div>
</main>

<?php if (!empty($office['whatsapp'])): ?>
<a class="wa-float" href="https://wa.me/<?= e($office['whatsapp']) ?>?text=Merhaba%2C+<?= rawurlencode($listing['title']) ?>+ilanı+hakkında+bilgi+almak+istiyorum." target="_blank">
    <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
</a>
<?php endif; ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>
<script>
// Gallery
function switchImg(el, src) {
    document.getElementById('main-img').src = src;
    document.querySelectorAll('.gallery-thumbs img').forEach(i => i.classList.remove('active'));
    el.classList.add('active');
}

// Leaflet Map - Nusaybin center, approximate location
const map = L.map('listing-map').setView([37.0667, 41.2167], 14);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap',
    maxZoom: 18
}).addTo(map);
const goldIcon = L.divIcon({
    html: '<div style="background:linear-gradient(135deg,#c9a35a,#a07830);width:32px;height:32px;border-radius:50% 50% 50% 0;transform:rotate(-45deg);border:2px solid #fff;box-shadow:0 4px 12px rgba(0,0,0,.4)"></div>',
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    className: ''
});
L.marker([37.0667, 41.2167], { icon: goldIcon })
    .addTo(map)
    .bindPopup('<strong><?= e(addslashes($listing['title'])) ?></strong><br><?= e(addslashes($listing['neighborhood'])) ?>, Nusaybin')
    .openPopup();
</script>
</body>
</html>
