<?php
require_once __DIR__ . '/../includes/functions.php';

global $nusaybinNeighborhoods;
$office = office_settings();

$listing = null;
if (!empty($_GET['listing_id'])) {
    $listing = find_listing((int) $_GET['listing_id']);
}

$saved = false;
$matches = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    require_fields(['full_name', 'phone', 'status']);
    if (!in_array(post('status'), ['Kiralik', 'Satilik'], true)) {
        flash('error', 'Lutfen gecerli bir talep tipi secin.');
        redirect('request.php');
    }
    if (post('neighborhood') !== '' && !in_array(post('neighborhood'), $nusaybinNeighborhoods, true)) {
        flash('error', 'Lutfen listeden gecerli bir mahalle secin.');
        redirect('request.php');
    }
    if (post('max_price') !== '' && (int) post('max_price') < 0) {
        flash('error', 'Butce negatif olamaz.');
        redirect('request.php');
    }
    $stmt = db()->prepare('INSERT INTO demands (full_name, phone, status, neighborhood, room_count, max_price, note, source_listing_id, created_at) VALUES (:full_name, :phone, :status, :neighborhood, :room_count, :max_price, :note, :source_listing_id, NOW())');
    $stmt->execute([
        'full_name' => trim((string) post('full_name')),
        'phone' => trim((string) post('phone')),
        'status' => post('status'),
        'neighborhood' => post('neighborhood'),
        'room_count' => post('room_count'),
        'max_price' => post('max_price') !== '' ? (int) post('max_price') : null,
        'note' => trim((string) post('note')),
        'source_listing_id' => post('source_listing_id') ?: null,
    ]);
    $demandId = (int) db()->lastInsertId();
    $demand = db()->query('SELECT * FROM demands WHERE id = ' . $demandId)->fetch();
    $matches = suitable_listings_for_demand($demand);
    $saved = true;
}
?>
<!doctype html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Talep olustur | <?= e($office['name']) ?></title>
    <link rel="stylesheet" href="assets/styles.css">
</head>
<body>
<header class="topbar"><div class="wrap nav"><a class="brand" href="index.php"><?= e($office['name']) ?></a></div></header>
<main class="section">
    <div class="wrap">
        <div class="panel">
            <h1>Talep olustur</h1>
            <?php foreach (flashes() as $flash): ?><div class="notice <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div><?php endforeach; ?>
            <?php if ($saved): ?>
                <div class="notice success">Talebiniz alindi. Ofis ekibi kriterlerinize uygun ilanlari kontrol edecek. Su an <?= count($matches) ?> uygun ilan gorunuyor.</div>
            <?php endif; ?>
            <form method="post" class="form-grid">
                <?= csrf_field() ?>
                <input name="full_name" placeholder="Ad soyad" required>
                <input name="phone" placeholder="Telefon numarasi" required>
                <select name="status" required>
                    <option value="">Talep tipi</option>
                    <option value="Kiralik"<?= $listing ? selected($listing['status'], 'Kiralik') : '' ?>>Kiralik</option>
                    <option value="Satilik"<?= $listing ? selected($listing['status'], 'Satilik') : '' ?>>Satilik</option>
                </select>
                <select name="neighborhood">
                    <option value="">Mahalle fark etmez</option>
                    <?php foreach ($nusaybinNeighborhoods as $neighborhood): ?>
                        <option value="<?= e($neighborhood) ?>"<?= $listing ? selected($listing['neighborhood'], $neighborhood) : '' ?>><?= e($neighborhood) ?></option>
                    <?php endforeach; ?>
                </select>
                <select name="room_count">
                    <option value="">Oda sayisi fark etmez</option>
                    <?php foreach (['1+1','2+1','3+1','4+1','5+1','Dukkan','Arsa'] as $room): ?>
                        <option value="<?= e($room) ?>"<?= $listing ? selected($listing['room_count'], $room) : '' ?>><?= e($room) ?></option>
                    <?php endforeach; ?>
                </select>
                <input type="number" name="max_price" placeholder="Maksimum butce">
                <textarea class="full" name="note" placeholder="Talep detayi, tasinma tarihi, lokasyon notu"></textarea>
                <input type="hidden" name="source_listing_id" value="<?= $listing ? (int) $listing['id'] : '' ?>">
                <button class="full" type="submit">Talebi kaydet</button>
            </form>
        </div>
    </div>
</main>
</body>
</html>
