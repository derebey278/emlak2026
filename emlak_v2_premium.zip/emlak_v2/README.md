# Emlak Ofisi Yönetim Sistemi — v2 (Lüks & Premium)

PHP + MySQL ile hazırlanmış, **tek emlak ofisine özel** tam özellikli ilan, talep ve kira sözleşmesi takip sistemi.

## Yeni Özellikler (v2)

- ✅ **Lüks & Premium Tasarım** — Koyu tema, altın/bronz aksanlar, Playfair Display font
- ✅ **Gelişmiş Arama & Filtreleme** — Fiyat, oda, konum, brüt/net m² filtresi
- ✅ **Harita Entegrasyonu** — Leaflet (ücretsiz, OpenStreetMap tabanlı)
- ✅ **Personel / Emlakçı Yönetimi** — Admin → Personel sayfası
- ✅ **Raporlama & Dashboard** — Aylık/oda/mahalle grafikleri (Chart.js)
- ✅ **AI ile İlan Açıklaması** — Claude API ile tek tıkla otomatik açıklama
- ✅ **WhatsApp Butonu** — Sabit köşe butonu + ilan detay sayfasında
- ✅ **Galeri Yönetimi** — Thumbnail geçişli fotoğraf galerisi
- ✅ **Ek İlan Alanları** — Net m², kat, bina yaşı, ısıtma türü

## Kurulum

1. `database/schema.sql` dosyasını import edin.
2. **Mevcut kurulumda** `database/migration_v2.sql` dosyasını bir kez çalıştırın.
3. `config/config.php` dosyasında `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS` ve `ADMIN_PASS` alanlarını güncelleyin.

## Varsayılan Giriş

- Kullanıcı adı: `admin`
- Şifre: `123456` (canlıya almadan önce `config/config.php`'den değiştirin)
